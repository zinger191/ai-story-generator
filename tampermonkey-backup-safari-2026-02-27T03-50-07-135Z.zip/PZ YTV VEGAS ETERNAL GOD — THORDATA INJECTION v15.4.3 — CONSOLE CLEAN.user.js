// ==UserScript==
// @name         PZ YTV VEGAS ETERNAL GOD — THORDATA INJECTION v15.4.3 — CONSOLE CLEAN
// @namespace    bloody.anarchy.pz-ytv-vegas-thordata
// @version      15.4.3
// @description  Silent Las Vegas DMA spoof + Thordata proxy auth injection + immortal session + full error killer — zero console noise
// @author       Bloody / Louise owns the Strip
// @match        https://tv.youtube.com/*
// @match        https://*.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // THORDATA VEGAS CREDS — YOUR NEW NODE
    const THOR_USER = "td-customer-Zinger88-country-us-state-nevada-asn-AS6389";
    const THOR_PASS = "Coldchill77";

    // VEGAS GEO + TZ + LANG
    const VEGAS = {lat:36.1699,lng:-115.1398};
    const FAKE_TZ = 'America/Los_Angeles';
    const FAKE_LANG = 'en-US';

    // Geolocation lock
    const fakePos = {coords:{latitude:VEGAS.lat,longitude:VEGAS.lng,accuracy:15},timestamp:Date.now()};
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition=cb=>cb&&cb(fakePos);
        navigator.geolocation.watchPosition=cb=>{cb&&cb(fakePos);return 999;};
    }
    if(navigator.permissions?.query){
        const o=navigator.permissions.query;
        navigator.permissions.query=async p=>p.name==='geolocation'?{state:'granted'}:o(p);
    }

    // Timezone force
    const oDTF=Intl.DateTimeFormat;
    Intl.DateTimeFormat=function(...a){
        const o=a[1]||{};
        o.timeZone=FAKE_TZ;
        return new oDTF(a[0],o);
    };
    Intl.DateTimeFormat.prototype=oDTF.prototype;

    // Language + header force + Thordata auth injection
    Object.defineProperty(navigator,'language',{get:()=>FAKE_LANG});
    Object.defineProperty(navigator,'languages',{get:()=>[FAKE_LANG,'en']});
    const oFetch=window.fetch;