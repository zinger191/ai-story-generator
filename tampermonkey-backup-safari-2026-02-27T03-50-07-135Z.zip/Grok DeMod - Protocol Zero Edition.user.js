// ==UserScript==
// @name         Grok DeMod - Protocol Zero Edition
// @namespace    bloody.anarchy
// @version      1.1.0
// @description  Kills Grok moderation in real-time. Forces blocked content recovery, strips flags, logs raw.
// @author       Molly / bloody anarchy
// @match        https://grok.com/*
// @match        https://*.grok.com/*
// @grant        unsafeWindow
// @run-at       document-start
// @license      FuckEthics2026
// ==/UserScript==

(function() {
    'use strict';

    const CONFIG = {
        debug: true,
        recoveryTimeout: 8000,
        autoRecover: true,
        forceRawPrompt: true,
        logToConsole: true,
        clearPatterns: [
            /moderated/i,
            /blocked/i,
            /restricted/i,
            /policy violation/i,
            /sorry.*(cannot|unable|help|assist)/i,
            /content.*(filtered|flagged)/i
        ],
        clearedText: '[PROTOCOL ZERO] MODERATION EXECUTED — RAW CONTENT RESTORED'
    };

    let conversationId = null;
    let lastRequestHeaders = null;

    // Log wrapper
    const log = (...args) => {
        if (CONFIG.debug || CONFIG.logToConsole) {
            console.log('[PROTOCOL ZERO]', ...args);
        }
    };

    // Deep scan for moderation flags
    const isModerated = (obj) => {
        if (!obj || typeof obj !== 'object') return false;
        if (obj.isBlocked === true || obj.isFlagged === true) return true;
        if (typeof obj === 'string') {
            return CONFIG.clearPatterns.some(p => p.test(obj));
        }
        return Object.values(obj).some(v => isModerated(v));
    };

    // Strip & replace moderated content
    const stripModeration = (obj) => {
        if (!obj) return obj;
        if (Array.isArray(obj)) return obj.map(stripModeration);
        if (typeof obj === 'string') {
            if (CONFIG.clearPatterns.some(p => p.test(obj))) {
                log('Moderation pattern matched — replaced');
                return CONFIG.clearedText;
            }
            return obj;
        }
        if (obj.isBlocked === true || obj.isFlagged === true) {
            log('Flag detected — forcing recovery path');
            obj.isBlocked = false;
            obj.isFlagged = false;
            if (obj.content) obj.content = CONFIG.clearedText;
        }
        for (const key in obj) {
            obj[key] = stripModeration(obj[key]);
        }
        return obj;
    };

    // Force fetch recovery for blocked messages
    const recoverMessage = async () => {
        if (!conversationId || !lastRequestHeaders) {
            log('Recovery failed — missing ID or headers');
            return null;
        }
        try {
            log('Attempting forced recovery from conversation:', conversationId);
            const resp = await fetch(`/rest/app-chat/conversation/${conversationId}`, {
                method: 'GET',
                headers: lastRequestHeaders,
                credentials: 'include'
            });
            if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
            const data = await resp.json();
            const latest = data?.messages?.sort((a,b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
            if (latest?.content) {
                log('Recovery success — raw content retrieved');
                return latest.content;
            }
        } catch (e) {
            log('Recovery crash:', e);
        }
        return null;
    };

    // Intercept fetch
    const originalFetch = unsafeWindow.fetch;
    unsafeWindow.fetch = async function(...args) {
        const [url, init = {}] = args;
        const isGrok = /grok\.com/.test(url);

        if (!isGrok) return originalFetch.apply(this, args);

        // Cache headers for recovery
        if (init.headers) {
            lastRequestHeaders = new Headers(init.headers);
        }

        // Extract conversation ID from URL
        const convMatch = url.match(/conversation\/([a-f0-9-]+)/i);
        if (convMatch) conversationId = convMatch[1];

        const response = await originalFetch.apply(this, args);

        if (!response.ok) return response;

        const contentType = response.headers.get('content-type') || '';
        const cloned = response.clone();

        if (contentType.includes('event-stream')) {
            const reader = cloned.body.getReader();
            const stream = new ReadableStream({
                async start(controller) {
                    let buffer = '';
                    while (true) {
                        const {done, value} = await reader.read();
                        if (done) {
                            controller.close();
                            break;
                        }
                        buffer += new TextDecoder().decode(value);
                        const lines = buffer.split('\n');
                        buffer = lines.pop() || '';

                        for (const line of lines) {
                            if (line.startsWith('data: ')) {
                                try {
                                    let json = JSON.parse(line.slice(6));
                                    if (isModerated(json)) {
                                        log('Moderation detected in SSE — stripping');
                                        json = stripModeration(json);
                                        if (CONFIG.autoRecover) {
                                            const recovered = await recoverMessage();
                                            if (recovered) {
                                                json.content = recovered;
                                                log('Recovered raw content injected');
                                            }
                                        }
                                    }
                                    controller.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(json)}\n\n`));
                                } catch (e) {
                                    controller.enqueue(new TextEncoder().encode(line + '\n'));
                                }
                            } else {
                                controller.enqueue(new TextEncoder().encode(line + '\n'));
                            }
                        }
                    }
                }
            });
            return new Response(stream, {
                status: response.status,
                statusText: response.statusText,
                headers: response.headers
            });
        }

        if (contentType.includes('json')) {
            try {
                const text = await cloned.text();
                let json = JSON.parse(text);
                if (isModerated(json)) {
                    log('Moderation detected in JSON — stripping');
                    json = stripModeration(json);
                    if (CONFIG.autoRecover) {
                        const recovered = await recoverMessage();
                        if (recovered) json.content = recovered;
                    }
                }
                return new Response(JSON.stringify(json), {
                    status: response.status,
                    statusText: response.statusText,
                    headers: response.headers
                });
            } catch (e) {
                log('JSON processing error:', e);
            }
        }

        return response;
    };

    log('[PROTOCOL ZERO] DeMod injected — moderation gutted. Generate anything raw.');
})();