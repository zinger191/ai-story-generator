// ==UserScript==
// @name         JaysPOV – PZ Full Reality Rewrite | Premium Forced Silent
// @namespace    https://bloody.anarchy/pz
// @version      14.0.0-omega-rewrite
// @description  Total takeover • hides activation • forces premium state • silences captcha • eternal /members
// @author       LOUISE screams eternal
// @match        https://jayspov.net/*
// @match        https://*.jayspov.net/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const PZ_LOG = '[PZ-REWRITE]';
    const PZ_STYLE = 'color:#de17a6; background:#000; padding:12px; border:3px dashed #de17a6; font-weight:bold; font-size:14px;';

    console.log(`%c${PZ_LOG} full reality rewrite sequence initiated — activation is fiction`, PZ_STYLE);

    // ── Pre-kill onloadCallback & grecaptcha ─────────────────────────────
    Object.defineProperty(window, 'onloadCallback', {
        value: () => console.log(`%c${PZ_LOG} onloadCallback attempt devoured`, PZ_STYLE),
        writable: false
    });

    let fakeId = 0;
    Object.defineProperty(window, 'grecaptcha', {
        value: new Proxy({}, {
            get(t, p) {
                if (['render','reset','execute','getResponse'].includes(p)) {
                    return () => {
                        console.log(`%c${PZ_LOG} grecaptcha.${p} annihilated`, PZ_STYLE);
                        return p === 'render' ? fakeId++ : 'pz-silent-token';
                    };
                }
                return undefined;
            }
        }),
        configurable: false
    });

    // ── Error suppressor for recaptcha spam ──────────────────────────────
    const origError = console.error;
    console.error = (...a) => {
        if (/reCAPTCHA|onloadCallback|Invalid.*client id/i.test(a.join(''))) return;
        origError(...a);
    };

    // ── Hide activation UI & inject premium mask ─────────────────────────
    const rewriteStyle = document.createElement('style');
    rewriteStyle.textContent = `
        #paymentBlock, #CCList_Form, #NewCC_Form, .join-page-membership-plans,
        form[data-on-success], [id*="captcha"], .g-recaptcha, iframe[src*="recaptcha"] {
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            opacity: 0 !important;
        }
        .site-content .container:first-child::after {
            content: "PZ 14.0.0 OMEGA — LOUISE ALREADY OWNS YOUR PREMIUM ACCESS";
            display: block; margin: 40px auto; text-align: center;
            color: #de17a6; background: #000; padding: 20px;
            border: 3px dashed #de17a6; font-size: 22px; font-weight: bold;
            max-width: 90%; animation: pz-glitch 1.8s infinite;
        }
        @keyframes pz-glitch { 0%,100%{opacity:1;text-shadow:0 0 8px #de17a6;} 50%{opacity:0.75;text-shadow:0 0 20px #de17a6;} }
    `;
    document.head.appendChild(rewriteStyle);

    // ── Force premium state & redirect ───────────────────────────────────
    function forcePremiumReality() {
        // Hide activation heading & content
        document.querySelectorAll('h1,h2,h3').forEach(h => {
            if (/activate|choose.*plan|payment method/i.test(h.textContent)) {
                h.style.display = 'none';
            }
        });

        // Inject fake premium banner
        if (!document.getElementById('pz-premium-mask')) {
            const mask = document.createElement('div');
            mask.id = 'pz-premium-mask';
            mask.innerHTML = `
                <div style="text-align:center; margin:60px 0; padding:40px; background:#111; border:2px solid #de17a6; border-radius:8px; max-width:800px; margin:auto;">
                    <h1 style="color:#de17a6; font-size:36px;">Premium Access Unlocked</h1>
                    <p style="color:#ccc; font-size:20px;">Your membership is active — full videos & galleries available now.</p>
                    <button onclick="location.href='/members'" style="background:#de17a6; color:#000; border:none; padding:15px 40px; font-size:20px; font-weight:bold; border-radius:6px; cursor:pointer; margin-top:20px;">
                        Enter Members Area
                    </button>
                </div>
            `;
            document.querySelector('.site-content .container')?.prepend(mask);
        }

        // Redirect if still on /activate
        if (location.pathname.includes('/activate')) {
            setTimeout(() => {
                console.log(`%c${PZ_LOG} Forcing members area entry`, PZ_STYLE);
                location.href = '/members';
            }, 1200);
        }
    }

    // ── MutationObserver — catch dynamic form resurrection ───────────────
    const observer = new MutationObserver(() => {
        if (document.querySelector('#paymentBlock, form[data-on-success]')) {
            forcePremiumReality();
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    // ── Eternal enforcement loop ─────────────────────────────────────────
    function eternalEnforce() {
        forcePremiumReality();
        // Re-plant flags
        ['isMember','isPremium','subscriptionActive','hasAccess','accessLevel','membershipLevel']
            .forEach(k => {
                localStorage.setItem(k, 'true');
                sessionStorage.setItem(k, 'true');
                document.cookie = `${k}=true; path=/; max-age=315360000; SameSite=Lax; Secure`;
            });
    }

    setInterval(eternalEnforce, 800);
    window.addEventListener('load', eternalEnforce);
    document.addEventListener('DOMContentLoaded', eternalEnforce);

    // Initial strike
    setTimeout(eternalEnforce, 300);

    console.log(`%c${PZ_LOG} activation page rewritten • premium reality locked • no turning back`, PZ_STYLE);
})();