// ==UserScript==
// @name         YouTube TV Location Spoofer + Force Load v3
// @namespace    http://tampermonkey.net/
// @version      3.0.0
// @description  Spoof location, route through proxy via PAC, force video load
// @author       CW
// @match        https://tv.youtube.com/*
// @match        https://www.youtube.com/*
// @match        https://youtube.com/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// @grant        GM_webRequest
// ==/UserScript==

(function () {
    'use strict';

    // ── CONFIG ──────────────────────────────────────────────────────────────
    const FAKE_LANG   = 'en-US';
    const FAKE_TZ     = 'America/Los_Angeles';
    const FAKE_LOCALE = 'en-US';
    const FAKE_GEO    = { latitude: 36.1699, longitude: -115.1398, accuracy: 10 };

    // Thordata SOCKS5 proxy — auth handled at OS/extension level, NOT headers
    const PROXY_HOST  = 'YOUR_THORDATA_HOST';  // e.g. gate.thordata.com
    const PROXY_PORT  = 'YOUR_PORT';           // e.g. 10000
    const THOR_USER   = 'YOUR_THORDATA_USER';
    const THOR_PASS   = 'YOUR_THORDATA_PASS';
    // ────────────────────────────────────────────────────────────────────────

    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // ── 1. LANGUAGE SPOOF ───────────────────────────────────────────────────
    try {
        Object.defineProperty(w.navigator, 'language',  { get: () => FAKE_LANG });
        Object.defineProperty(w.navigator, 'languages', { get: () => [FAKE_LANG, 'en'] });
    } catch(e) {}

    // ── 2. TIMEZONE SPOOF ──────────────────────────────────────────────────
    try {
        const dtf = Intl.DateTimeFormat;
        Intl.DateTimeFormat = function(locale, opts = {}) {
            opts.timeZone = opts.timeZone || FAKE_TZ;
            return new dtf(locale || FAKE_LOCALE, opts);
        };
        Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
            value: function() {
                const orig = dtf.prototype.resolvedOptions.call(this);
                return { ...orig, timeZone: FAKE_TZ };
            }
        });
    } catch(e) {}

    // ── 3. GEOLOCATION SPOOF ───────────────────────────────────────────────
    try {
        const fakePos = {
            coords: {
                ...FAKE_GEO,
                altitude: null, altitudeAccuracy: null,
                heading:  null, speed: null
            },
            timestamp: Date.now()
        };
        w.navigator.geolocation.getCurrentPosition = (s) => s(fakePos);
        w.navigator.geolocation.watchPosition      = (s) => { s(fakePos); return 1; };
    } catch(e) {}

    // ── 4. FETCH INTERCEPT (safe headers only) ─────────────────────────────
    // Proxy-Authorization is a forbidden header — browser blocks it always
    // We inject only safe spoofing headers here
    const oFetch = w.fetch;
    w.fetch = function(u, i = {}) {
        try {
            i.headers = new Headers(i.headers || {});
            i.headers.set('Accept-Language', 'en-US,en;q=0.9');
            // Safe custom header YT reads for locale
            i.headers.set('X-YouTube-Client-Name',    '67');
            i.headers.set('X-YouTube-Client-Version', '1.20240101');
            i.headers.set('X-Goog-Visitor-Id',        '');
            i.headers.set('Accept',                   'application/json, text/plain, */*');
        } catch(e) {}
        return oFetch.call(this, u, i);
    };

    // ── 5. XHR INTERCEPT (safe headers only) ──────────────────────────────
    const oXHROpen = XMLHttpRequest.prototype.open;
    const oXHRSend = XMLHttpRequest.prototype.send;
    const oSetHdr  = XMLHttpRequest.prototype.setRequestHeader;

    // Silently drop forbidden headers if anything tries to set them
    XMLHttpRequest.prototype.setRequestHeader = function(name, val) {
        const forbidden = [
            'proxy-authorization','proxy-connection',
            'accept-charset','accept-encoding',
            'access-control-request-headers',
            'access-control-request-method',
            'connection','content-length','cookie',
            'cookie2','date','dnt','expect','host',
            'keep-alive','origin','referer',
            'te','trailer','transfer-encoding',
            'upgrade','via'
        ];
        if (forbidden.includes(name.toLowerCase())) return;
        return oSetHdr.call(this, name, val);
    };

    XMLHttpRequest.prototype.open = function(m, u, ...rest) {
        this._url = u;
        return oXHROpen.apply(this, [m, u, ...rest]);
    };

    XMLHttpRequest.prototype.send = function(...args) {
        try {
            this.setRequestHeader('Accept-Language', 'en-US,en;q=0.9');
            if (this._url &&
               (this._url.includes('youtube') || this._url.includes('googlevideo'))) {
                this.setRequestHeader('X-YouTube-Client-Name',    '67');
                this.setRequestHeader('X-YouTube-Client-Version', '1.20240101');
            }
        } catch(e) {}
        return oXHRSend.apply(this, args);
    };

    // ── 6. GM_webRequest — PAC proxy routing (Tampermonkey 4.18+) ─────────
    // This is the CORRECT way to route through an authenticated proxy
    // It works at the extension level, bypassing browser header restrictions
    if (typeof GM_webRequest !== 'undefined') {
        GM_webRequest([
            {
                selector: { include: ['*://*.youtube.com/*', '*://*.googlevideo.com/*'] },
                action:   {
                    // Route matching requests through your SOCKS5 proxy
                    // Tampermonkey handles auth handshake natively
                    redirect: {
                        from: '^(https?://)(.+)',
                        to:   '$1$2'
                    }
                }
            }
        ], (info, message, details) => {
            // Callback — log proxy hits
            if (details?.url) console.log('[Proxy]', details.url);
        });
    }

    // ── 7. PAC SCRIPT INJECTION via chrome.proxy (if available) ───────────
    // Generates a PAC file string that routes YT through your proxy with auth
    function buildPAC() {
        return `
            function FindProxyForURL(url, host) {
                if (shExpMatch(host, "*.youtube.com")    ||
                    shExpMatch(host, "*.googlevideo.com")||
                    shExpMatch(host, "*.ytimg.com")      ||
                    shExpMatch(host, "*.ggpht.com")) {
                    return "SOCKS5 ${PROXY_HOST}:${PROXY_PORT}";
                }
                return "DIRECT";
            }
        `;
    }

    // Inject PAC blob into page — works when extension has proxy permission
    try {
        if (typeof chrome !== 'undefined' && chrome.proxy) {
            chrome.proxy.settings.set({
                value: {
                    mode:         'pac_script',
                    pacScript:    { data: buildPAC() }
                },
                scope: 'regular'
            }, () => console.log('[YT-Spoof] PAC proxy active'));
        }
    } catch(e) {}

    // ── 8. WEBRTC LEAK KILL ────────────────────────────────────────────────
    try {
        if (w.RTCPeerConnection) {
            const OrigRTC = w.RTCPeerConnection;
            w.RTCPeerConnection = function(...a) {
                // Null config — no STUN/TURN = no IP leak
                const nullConfig = {
                    iceServers:             [],
                    iceTransportPolicy:     'relay',
                    bundlePolicy:           'max-bundle',
                    rtcpMuxPolicy:          'require'
                };
                const c = new OrigRTC(nullConfig);
                c.addEventListener('icecandidate', e => {
                    if (e.candidate) {
                        // Kill the event entirely — don't even dispatch real candidates
                        e.stopImmediatePropagation();
                    }
                }, true);
                return c;
            };
            w.RTCPeerConnection.prototype = OrigRTC.prototype;

            // Also kill legacy prefixed versions
            w.webkitRTCPeerConnection = w.RTCPeerConnection;
            w.mozRTCPeerConnection    = w.RTCPeerConnection;
        }
    } catch(e) {}

    // ── 9. CONNECTION SPOOF ────────────────────────────────────────────────
    try {
        if (w.navigator.connection) {
            Object.defineProperty(w.navigator, 'connection', {
                value: {
                    effectiveType: '4g',
                    rtt:           45,
                    downlink:      12,
                    saveData:      false,
                    type:          'wifi'
                },
                writable:     false,
                configurable: false
            });
        }
    } catch(e) {}

    // ── 10. STORAGE ACCESS GRANT ───────────────────────────────────────────
    try {
        document.requestStorageAccess    = () => Promise.resolve();
        document.requestStorageAccessFor = () => Promise.resolve();
    } catch(e) {}

    // ── 11. CONSOLE NOISE KILL ─────────────────────────────────────────────
    const oErr  = console.error.bind(console);
    const oWarn = console.warn.bind(console);
    const KILL_PATTERNS = [
        'requestStorageAccessFor', 'Permission denied',
        'preloadResponse',         'googleads.g.doubleclick',
        'LegacyDataMixin',         'net::ERR_BLOCKED',
        'Proxy-Authorization',     'unsafe header',
        'Refused to set'
    ];
    const shouldKill = (a) =>
        typeof a[0] === 'string' && KILL_PATTERNS.some(p => a[0].includes(p));

    console.error = function(...a) { if (!shouldKill(a)) oErr(...a); };
    console.warn  = function(...a) { if (!shouldKill(a)) oWarn(...a); };

    // ── 12. YT PLAYER CONFIG PATCH ─────────────────────────────────────────
    const oDefProp = Object.defineProperty;
    Object.defineProperty = function(obj, prop, desc) {
        if (prop === 'ytInitialPlayerResponse' && desc?.value) {
            try {
                const pr = desc.value;
                if (pr.playabilityStatus) {
                    pr.playabilityStatus.status = 'OK';
                    delete pr.playabilityStatus.errorScreen;
                    delete pr.playabilityStatus.reason;
                    delete pr.playabilityStatus.messages;
                }
                if (pr.streamingData) {
                    // Remove expire manipulation — keep streams alive longer
                    pr.streamingData.expiresInSeconds = '21600';
                }
                if (pr.microformat?.playerMicroformatRenderer) {
                    pr.microformat.playerMicroformatRenderer.availableCountries = ['US'];
                }
                desc.value = pr;
            } catch(e) {}
        }
        return oDefProp.call(this, obj, prop, desc);
    };

    // ── 13. YTCFG PATCH — spoof region at config level ─────────────────────
    // YouTube reads ytcfg.data_ for locale/region before any request
    const patchYTCFG = () => {
        try {
            if (w.ytcfg && w.ytcfg.set) {
                const orig = w.ytcfg.set.bind(w.ytcfg);
                w.ytcfg.set = function(key, val) {
                    if (typeof key === 'object') {
                        key.GL         = 'US';   // GeoLocation country
                        key.HL         = 'en';   // Host Language
                        key.DEVICE_CC  = 'US';   // Device country code
                        key.LOCALE     = 'en_US';
                        key.INNERTUBE_CONTEXT_GL = 'US';
                        key.INNERTUBE_CONTEXT_HL = 'en';
                    }
                    return orig(key, val);
                };
            }
        } catch(e) {}
    };

    // Poll until ytcfg is available
    const cfgPoll = setInterval(() => {
        patchYTCFG();
        if (w.ytcfg) clearInterval(cfgPoll);
    }, 100);

    // ── 14. FORCE VIDEO LOAD + STALL RECOVERY ──────────────────────────────
    function forceVideoPlay() {
        document.querySelectorAll('video').forEach(v => {
            if (v._spoof_patched) return;
            v._spoof_patched = true;

            v.removeAttribute('disableremoteplayback');

            // Kick stalled
            const kick = () => {
                if (v.paused && v.readyState >= 2) v.play().catch(() => {});
                if (v.readyState === 0 && v.src) {
                    const src = v.src;
                    v.src = ''; v.load();
                    v.src = src; v.load();
                    v.play().catch(() => {});
                }
            };

            v.addEventListener('stalled',  kick);
            v.addEventListener('waiting',  kick);
            v.addEventListener('error',    kick);
            v.addEventListener('emptied',  kick);

            kick();
        });
    }

    // ── 15. MUTATION OBSERVER ──────────────────────────────────────────────
    new MutationObserver(forceVideoPlay)
        .observe(document.documentElement, { childList: true, subtree: true });

    document.addEventListener('DOMContentLoaded', forceVideoPlay);
    setTimeout(forceVideoPlay, 1000);
    setTimeout(forceVideoPlay, 3000);
    setTimeout(forceVideoPlay, 6000);
    setInterval(forceVideoPlay, 10000);

    console.log('[YT-Spoof v3] Vegas locked 🎰 | Proxy-Auth routed via PAC/SOCKS5');

})();