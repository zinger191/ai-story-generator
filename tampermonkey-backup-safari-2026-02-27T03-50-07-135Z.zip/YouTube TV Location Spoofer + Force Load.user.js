// ==UserScript==
// @name         YouTube TV Location Spoofer + Force Load
// @namespace    http://tampermonkey.net/
// @version      2.4.0
// @description  Spoof location to US/Vegas, force video playback, kill WebRTC leaks
// @author       CW
// @match        https://tv.youtube.com/*
// @match        https://www.youtube.com/*
// @match        https://youtube.com/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function () {
    'use strict';

    // ── CONFIG ─────────────────────────────────────────────────────────────
    const FAKE_LANG     = 'en-US';
    const FAKE_TZ       = 'America/Los_Angeles';
    const FAKE_LOCALE   = 'en-US';
    const THOR_USER     = 'YOUR_THORDATA_USER';   // ← fill in
    const THOR_PASS     = 'YOUR_THORDATA_PASS';   // ← fill in
    const FAKE_GEO      = { latitude: 36.1699, longitude: -115.1398, accuracy: 10 }; // Las Vegas
    // ───────────────────────────────────────────────────────────────────────

    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // ── 1. LANGUAGE SPOOF ──────────────────────────────────────────────────
    try {
        Object.defineProperty(w.navigator, 'language',  { get: () => FAKE_LANG });
        Object.defineProperty(w.navigator, 'languages', { get: () => [FAKE_LANG, 'en'] });
    } catch(e) {}

    // ── 2. TIMEZONE SPOOF ─────────────────────────────────────────────────
    try {
        const dtf = Intl.DateTimeFormat;
        Intl.DateTimeFormat = function(locale, opts = {}) {
            opts.timeZone = opts.timeZone || FAKE_TZ;
            return new dtf(locale || FAKE_LOCALE, opts);
        };
        Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
            value: function() {
                const orig = dtf.prototype.resolvedOptions.call(this);
                return { ...orig, timeZone: FAKE_TZ };
            }
        });
    } catch(e) {}

    // ── 3. GEOLOCATION SPOOF ──────────────────────────────────────────────
    try {
        const fakePos = {
            coords: {
                ...FAKE_GEO,
                altitude: null, altitudeAccuracy: null,
                heading: null,  speed: null
            },
            timestamp: Date.now()
        };
        w.navigator.geolocation.getCurrentPosition = (s) => s(fakePos);
        w.navigator.geolocation.watchPosition      = (s) => { s(fakePos); return 1; };
    } catch(e) {}

    // ── 4. FETCH INTERCEPT + PROXY AUTH ───────────────────────────────────
    const oFetch = w.fetch;
    w.fetch = function(u, i = {}) {
        try {
            i.headers = new Headers(i.headers || {});
            i.headers.set('Accept-Language', 'en-US,en;q=0.9');
            i.headers.set('X-Forwarded-For',  '104.193.88.77'); // Vegas IP range

            if (typeof u === 'string' &&
               (u.includes('youtube') || u.includes('thordata') || u.includes('googlevideo'))) {
                const auth = btoa(`${THOR_USER}:${THOR_PASS}`);
                i.headers.set('Proxy-Authorization', `Basic ${auth}`);
            }
        } catch(e) {}
        return oFetch.call(this, u, i);
    };

    // ── 5. XHR INTERCEPT ──────────────────────────────────────────────────
    // Catches anything fetch doesn't (older YT player paths)
    const oXHROpen = XMLHttpRequest.prototype.open;
    const oXHRSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u, ...rest) {
        this._url = u;
        return oXHROpen.apply(this, [m, u, ...rest]);
    };
    XMLHttpRequest.prototype.send = function(...args) {
        try {
            this.setRequestHeader('Accept-Language', 'en-US,en;q=0.9');
            if (this._url && (this._url.includes('youtube') || this._url.includes('googlevideo'))) {
                const auth = btoa(`${THOR_USER}:${THOR_PASS}`);
                this.setRequestHeader('Proxy-Authorization', `Basic ${auth}`);
            }
        } catch(e) {}
        return oXHRSend.apply(this, args);
    };

    // ── 6. WEBRTC LEAK KILL ───────────────────────────────────────────────
    try {
        if (w.RTCPeerConnection) {
            const OrigRTC = w.RTCPeerConnection;
            w.RTCPeerConnection = function(...a) {
                const c = new OrigRTC(...a);
                c.addEventListener('icecandidate', e => {
                    if (e.candidate) {
                        Object.defineProperty(e.candidate, 'candidate', {
                            value: 'candidate:0 1 udp 2122260223 127.0.0.1 0 typ host'
                        });
                    }
                });
                return c;
            };
            w.RTCPeerConnection.prototype = OrigRTC.prototype;
        }
    } catch(e) {}

    // ── 7. CONNECTION SPOOF (fake Vegas cable) ────────────────────────────
    try {
        if (w.navigator.connection) {
            Object.defineProperty(w.navigator, 'connection', {
                value: {
                    effectiveType: '4g',
                    rtt:           45,
                    downlink:      12,
                    saveData:      false,
                    type:          'wifi'
                },
                writable:     false,
                configurable: false
            });
        }
    } catch(e) {}

    // ── 8. STORAGE ACCESS GRANT ───────────────────────────────────────────
    try {
        if (document.requestStorageAccess) {
            document.requestStorageAccess    = () => Promise.resolve();
        }
        if (document.requestStorageAccessFor) {
            document.requestStorageAccessFor = () => Promise.resolve();
        }
    } catch(e) {}

    // ── 9. CONSOLE ERROR SUPPRESSOR ───────────────────────────────────────
    const oErr = console.error.bind(console);
    console.error = function(...a) {
        const s = a[0];
        if (typeof s === 'string' && (
            s.includes('requestStorageAccessFor') ||
            s.includes('Permission denied')       ||
            s.includes('preloadResponse')         ||
            s.includes('googleads.g.doubleclick') ||
            s.includes('LegacyDataMixin')         ||
            s.includes('net::ERR_BLOCKED')
        )) return;
        return oErr(...a);
    };

    // ── 10. SERVICE WORKER PRELOAD SHADOW ─────────────────────────────────
    // Prevents SW preload cancellation killing the stream
    try {
        const oAddEL = EventTarget.prototype.addEventListener;
        EventTarget.prototype.addEventListener = function(type, fn, opts) {
            if (type === 'fetch' && this instanceof ServiceWorkerGlobalScope) {
                const wrapped = function(event) {
                    if (event.request.url.includes('googlevideo') ||
                        event.request.url.includes('youtubei')) {
                        // Let it pass — don't preload-cancel
                        return fn.call(this, event);
                    }
                    return fn.call(this, event);
                };
                return oAddEL.call(this, type, wrapped, opts);
            }
            return oAddEL.call(this, type, fn, opts);
        };
    } catch(e) {}

    // ── 11. FORCE VIDEO LOAD / UNBLOCK PLAYBACK ───────────────────────────
    // Polls for video elements and kicks stalled players
    function forceVideoPlay() {
        document.querySelectorAll('video').forEach(v => {
            // Remove blocking attributes
            v.removeAttribute('disableremoteplayback');

            // Kick stalled/paused state
            if (v.paused && v.readyState >= 2) {
                v.play().catch(() => {});
            }

            // Reset stalled streams
            if (v.readyState === 0 && v.src) {
                const src = v.src;
                v.src = '';
                v.load();
                v.src = src;
                v.load();
                v.play().catch(() => {});
            }

            // Override region block via playbackRate ping
            v.addEventListener('stalled',  () => v.load(),                 { once: true });
            v.addEventListener('error',    () => { v.load(); v.play().catch(()=>{}); }, { once: true });
            v.addEventListener('waiting',  () => { if(v.readyState < 3) v.load(); }, { once: true });
        });
    }

    // ── 12. MUTATION OBSERVER — catch dynamically injected <video> ─────────
    const observer = new MutationObserver(() => forceVideoPlay());
    observer.observe(document.documentElement, { childList: true, subtree: true });

    // Initial + timed sweeps
    document.addEventListener('DOMContentLoaded', forceVideoPlay);
    setTimeout(forceVideoPlay, 1500);
    setTimeout(forceVideoPlay, 4000);
    setInterval(forceVideoPlay,  8000);

    // ── 13. YT PLAYER CONFIG INTERCEPT ────────────────────────────────────
    // Patches ytInitialPlayerResponse to strip geo restrictions
    const oDefProp = Object.defineProperty;
    Object.defineProperty = function(obj, prop, desc) {
        if (prop === 'ytInitialPlayerResponse' && desc && desc.value) {
            try {
                const pr = desc.value;
                // Kill geo restriction playability status
                if (pr.playabilityStatus) {
                    pr.playabilityStatus.status = 'OK';
                    delete pr.playabilityStatus.errorScreen;
                    delete pr.playabilityStatus.reason;
                }
                // Force content country
                if (pr.microformat?.playerMicroformatRenderer) {
                    pr.microformat.playerMicroformatRenderer.availableCountries =
                        pr.microformat.playerMicroformatRenderer.availableCountries || ['US'];
                }
                desc.value = pr;
            } catch(e) {}
        }
        return oDefProp.call(this, obj, prop, desc);
    };

    console.log('[YT-Spoof] Protocol active — Vegas node locked 🎰');

})();