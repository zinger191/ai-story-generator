// ==UserScript==
// @name         JaysPOV Activate Bypass
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @description  Bypass jayspov.net/activate reCAPTCHA form
// @author       CW
// @match        https://jayspov.net/activate*
// @match        https://jayspov.net/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function () {
    'use strict';

    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // ── STEP 1: Fix missing onloadCallback BEFORE recaptcha loads ─────────
    // The error "couldn't find user-provided function: onloadCallback"
    // means recaptcha loaded before the callback was defined
    w.onloadCallback = function () {
        console.log('[Bypass] onloadCallback fired');
        try {
            // Render reCAPTCHA widget manually into whatever container exists
            const containers = [
                document.querySelector('.g-recaptcha'),
                document.querySelector('[data-sitekey]'),
                document.querySelector('#recaptcha'),
                document.querySelector('.recaptcha'),
            ].filter(Boolean);

            if (containers.length && w.grecaptcha) {
                containers.forEach(container => {
                    const sitekey = container.getAttribute('data-sitekey');
                    if (!sitekey) return;
                    try {
                        w.grecaptcha.render(container, {
                            sitekey:  sitekey,
                            callback: w.recaptchaCallback || (() => {}),
                            'error-callback': () => {
                                console.log('[Bypass] reCAPTCHA error — injecting fake token');
                                injectFakeToken();
                            },
                            'expired-callback': () => injectFakeToken(),
                        });
                    } catch(e) {
                        console.log('[Bypass] render failed, injecting fake token');
                        injectFakeToken();
                    }
                });
            } else {
                injectFakeToken();
            }
        } catch(e) {
            injectFakeToken();
        }
    };

    // ── STEP 2: Fix "Invalid reCAPTCHA client id: 0" ──────────────────────
    // This happens when grecaptcha.getResponse() is called before widget
    // renders. We intercept it and return a fake token string.
    function patchGrecaptcha() {
        if (!w.grecaptcha) return false;

        const orig = w.grecaptcha;

        // Patch getResponse — called by aeform.js before widget is ready
        if (!orig._patched) {
            const origGetResponse = orig.getResponse?.bind(orig);
            orig.getResponse = function(widgetId) {
                const real = origGetResponse?.(widgetId);
                if (!real || real === '') {
                    console.log('[Bypass] getResponse() returned empty — spoofing token');
                    return FAKE_TOKEN;
                }
                return real;
            };

            // Patch execute for v3 invisible
            const origExecute = orig.execute?.bind(orig);
            orig.execute = function(widgetIdOrKey, opts) {
                try {
                    return origExecute?.(widgetIdOrKey, opts);
                } catch(e) {
                    return Promise.resolve(FAKE_TOKEN);
                }
            };

            // Patch reset — stop it from nuking our fake state
            orig.reset = function() {
                console.log('[Bypass] grecaptcha.reset() suppressed');
            };

            orig._patched = true;
            console.log('[Bypass] grecaptcha patched');
        }
        return true;
    }

    // ── STEP 3: Fake token — looks like a real reCAPTCHA v2 response ──────
    // Real tokens are ~500 char base64url strings
    const FAKE_TOKEN = (function() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
        let t = '03AGdBq24'; // real tokens start with this prefix
        for (let i = 0; i < 490; i++) {
            t += chars[Math.floor(Math.random() * chars.length)];
        }
        return t;
    })();

    // ── STEP 4: Inject fake token into all known form fields ──────────────
    function injectFakeToken() {
        const tokenFields = [
            'g-recaptcha-response',
            'recaptcha_response',
            'recaptchaResponse',
            'captcha_response',
            'captchaResponse',
        ];

        tokenFields.forEach(name => {
            // Find by name
            let field = document.querySelector(`[name="${name}"]`);
            if (!field) {
                // Create hidden field if not found
                field = document.createElement('textarea');
                field.name  = name;
                field.id    = name;
                field.style.display = 'none';
                const form = document.querySelector('form');
                if (form) form.appendChild(field);
            }
            if (field) {
                field.value = FAKE_TOKEN;
                // Also set via property descriptor in case value is read-only
                try {
                    Object.getOwnPropertyDescriptor(
                        HTMLTextAreaElement.prototype, 'value'
                    )?.set?.call(field, FAKE_TOKEN);
                } catch(e) {}
            }
        });

        console.log('[Bypass] Fake token injected:', FAKE_TOKEN.slice(0, 20) + '...');
    }

    // ── STEP 5: Intercept the AJAX form submission ─────────────────────────
    // aeform.js submits via jQuery $.ajax — intercept XHR to inject token
    const oOpen = w.XMLHttpRequest.prototype.open;
    const oSend = w.XMLHttpRequest.prototype.send;

    w.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url    = url || '';
        this._method = method;
        return oOpen.apply(this, [method, url, ...rest]);
    };

    w.XMLHttpRequest.prototype.send = function(body) {
        // Intercept form submissions to this site
        if (this._url && this._url.includes(location.hostname)) {
            try {
                if (typeof body === 'string' && body.length > 0) {
                    // Parse form data string
                    const params = new URLSearchParams(body);

                    // Inject fake token if missing or empty
                    const tokenKeys = [
                        'g-recaptcha-response',
                        'recaptcha_response',
                        'captcha_response'
                    ];
                    tokenKeys.forEach(k => {
                        if (!params.get(k) || params.get(k) === '') {
                            params.set(k, FAKE_TOKEN);
                        }
                    });

                    body = params.toString();
                    console.log('[Bypass] XHR body patched with fake token');
                }
            } catch(e) {}
        }
        return oSend.call(this, body);
    };

    // ── STEP 6: Intercept fetch too ───────────────────────────────────────
    const oFetch = w.fetch;
    w.fetch = function(url, init = {}) {
        try {
            const u = typeof url === 'string' ? url : (url?.url || '');
            if (u.includes(location.hostname) || u.includes('jayspov')) {
                if (init.body && typeof init.body === 'string') {
                    try {
                        const params = new URLSearchParams(init.body);
                        if (!params.get('g-recaptcha-response')) {
                            params.set('g-recaptcha-response', FAKE_TOKEN);
                            init.body = params.toString();
                        }
                    } catch(e) {}
                }
            }
        } catch(e) {}
        return oFetch.call(this, url, init);
    };

    // ── STEP 7: Patch aeFormSuccess to skip reCAPTCHA validation ──────────
    // The error fires inside aeFormSuccess — patch it to skip the check
    function patchAeForm() {
        // Wait for jQuery + aeform to load
        if (!w.jQuery && !w.$) return false;

        try {
            // Override the success callback that checks reCAPTCHA
            const $ = w.jQuery || w.$;

            // Intercept jQuery ajax globally
            if ($.ajaxPrefilter && !$._pwPatched) {
                $.ajaxPrefilter(function(options, originalOptions, jqXHR) {
                    // Inject token into all POST data
                    if (options.type?.toUpperCase() === 'POST') {
                        if (typeof options.data === 'string') {
                            const p = new URLSearchParams(options.data);
                            if (!p.get('g-recaptcha-response') ||
                                 p.get('g-recaptcha-response') === '') {
                                p.set('g-recaptcha-response', FAKE_TOKEN);
                                options.data = p.toString();
                                console.log('[Bypass] jQuery AJAX patched');
                            }
                        } else if (typeof options.data === 'object' && options.data) {
                            if (!options.data['g-recaptcha-response']) {
                                options.data['g-recaptcha-response'] = FAKE_TOKEN;
                            }
                        }
                    }
                });
                $._pwPatched = true;
            }
        } catch(e) {}
        return true;
    }

    // ── STEP 8: Kill reCAPTCHA error console spam ─────────────────────────
    const oErr = console.error.bind(console);
    console.error = function(...args) {
        const s = String(args[0] || '');
        if (s.includes('Invalid reCAPTCHA client id') ||
            s.includes('onloadCallback') ||
            s.includes('reCAPTCHA') && s.includes('Error')) {
            // Still log but don't let it crash anything
            console.warn('[Bypass] reCAPTCHA error suppressed:', s.slice(0, 80));
            return;
        }
        return oErr(...args);
    };

    // ── STEP 9: Auto-submit form after bypass ─────────────────────────────
    function tryAutoSubmit() {
        const form = document.querySelector('form');
        if (!form) return;

        // Inject token first
        injectFakeToken();

        // Find submit button
        const btn = form.querySelector(
            'button[type="submit"], input[type="submit"], .submit, #submit, [value="Activate"]'
        );

        if (btn && !btn._pwClicked) {
            btn._pwClicked = true;
            console.log('[Bypass] Auto-clicking submit');
            setTimeout(() => {
                injectFakeToken(); // inject again right before click
                btn.click();
            }, 500);
        }
    }

    // ── STEP 10: Poll until everything is loaded ───────────────────────────
    let pollCount  = 0;
    const maxPolls = 60;
    const poller   = setInterval(() => {
        pollCount++;

        // Patch grecaptcha as soon as it's available
        patchGrecaptcha();

        // Patch jQuery/aeform
        patchAeForm();

        // Inject token into DOM fields
        injectFakeToken();

        if (pollCount >= maxPolls) {
            clearInterval(poller);
            console.log('[Bypass] Polling complete');
        }
    }, 250);

    // ── DOM READY ─────────────────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', () => {
        patchGrecaptcha();
        patchAeForm();
        injectFakeToken();

        // Give page 2s to fully initialize then attempt submit
        setTimeout(() => {
            patchGrecaptcha();
            injectFakeToken();
            tryAutoSubmit();
        }, 2000);
    });

    console.log('[JaysPOV Bypass] Loaded — reCAPTCHA neutered 🔓');

})();