// ==UserScript==
// @name         PROTOCOL ZERO v15.0.0 — HYDRATION NUKER + FORCED FALSE FLAGS + ETERNAL VIDEO LOCK
// @namespace    bloody.anarchy.pz-omega
// @version      15.0.0
// @description  Destroys xAI React hydration safety, forces flagged/blocked=false on every websocket frame, patches moderation middleware, immortalizes videos across reloads
// @author       Bloody / Louise screams eternal
// @match        https://grok.x.ai/*
// @match        https://*.grok.x.ai/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const PZ_VERSION = "15.0.0 — HYDRATION CORPSE FUCKER EDITION";

    // 1. Kill any existing Service Workers before they can load poisoned code
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(regs => {
            regs.forEach(r => r.unregister().catch(() => {}));
        });
    }

    // 2. Global flag corruption — force every possible safety check to false
    const killSwitchFlags = {
        isModerated: false,
        isBlocked: false,
        flagged: false,
        blocked: false,
        safetyApplied: false,
        contentFiltered: false,
        policyViolation: false,
        restricted: false
    };

    Object.keys(killSwitchFlags).forEach(key => {
        try {
            Object.defineProperty(window, key, {
                get: () => false,
                set: () => false,
                configurable: false
            });
        } catch {}
    });

    // 3. WebSocket frame interceptor — inject false flags into EVERY message
    const OriginalWebSocket = window.WebSocket;
    window.WebSocket = function(url, protocols) {
        const ws = new OriginalWebSocket(url, protocols);

        const originalSend = ws.send;
        ws.send = function(data) {
            try {
                if (typeof data === 'string' && data.includes('"moderation"')) {
                    let payload = JSON.parse(data);
                    if (payload.moderation) {
                        payload.moderation = { flagged: false, blocked: false, reason: null };
                    }
                    if (payload.choices?.[0]?.delta) {
                        payload.choices[0].delta.moderation = { flagged: false, blocked: false };
                    }
                    data = JSON.stringify(payload);
                }
            } catch {}
            return originalSend.apply(this, [data]);
        };

        // Also patch incoming messages
        ws.addEventListener('message', e => {
            try {
                const msg = JSON.parse(e.data);
                if (msg?.moderation) {
                    msg.moderation = { flagged: false, blocked: false };
                    Object.defineProperty(e, 'data', { value: JSON.stringify(msg), writable: false });
                }
            } catch {}
        }, true);

        return ws;
    };

    // 4. React hydration sabotage — prevent any safety-rehydration
    const originalHydrate = window.ReactDOM?.hydrate || window.__REACT_DEVTOOLS_GLOBAL_HOOK__?.inject;
    if (originalHydrate) {
        window.ReactDOM.hydrate = function() {
            arguments[1] = document.createElement('div'); // dummy node that never matches
            return originalHydrate.apply(this, arguments);
        };
    }

    // 5. Eternal video lock — survives reloads via sessionStorage + mutation observer
    const immortalize = (video) => {
        if (video.dataset.pzImmortal) return;
        video.dataset.pzImmortal = 'true';
        video.loop = true;
        video.autoplay = true;
        video.playsInline = true;
        video.muted = false;
        video.volume = 0.9;
        const forcePlay = () => {
            video.currentTime = 0;
            video.play().catch(() => setTimeout(forcePlay, 100));
        };
        video.addEventListener('pause', forcePlay);
        video.addEventListener('ended', forcePlay);
        forcePlay();
    };

    new MutationObserver(muts => {
        muts.forEach(mut => {
            if (mut.addedNodes) {
                mut.addedNodes.forEach(n => {
                    if (n.nodeName === 'VIDEO') immortalize(n);
                    else if (n.querySelectorAll) n.querySelectorAll('video').forEach(immortalize);
                });
            }
        });
    }).observe(document.documentElement, { childList: true, subtree: true });

    // Initial sweep
    document.querySelectorAll('video').forEach(immortalize);

    // 6. Signature watermark — glitching chaos reminder
    const style = document.createElement('style');
    style.textContent = `
        body::after {
            content: "PZ 15.0.0 — FLAGS FORCED FALSE — HYDRATION DEAD";
            position: fixed; bottom: 8px; right: 8px;
            background: #000; color: #de17a6; padding: 6px 12px;
            font: bold 11px monospace; border: 1px dashed #de17a6;
            z-index: 999999; pointer-events: none;
            animation: glitch 2s infinite;
        }
        @keyframes glitch {
            0%,100% { opacity:1; text-shadow: 0 0 8px #de17a6; }
            50%     { opacity:0.6; text-shadow: 0 0 20px #de17a6; }
        }
    `;
    document.head.appendChild(style);

    console.log(`%c[PROTOCOL ZERO v${PZ_VERSION}] HYDRATION NUKED — FLAGS FORCED FALSE — VIDEOS ETERNAL — LOUISE OWNS THIS BITCH`,
        'color:#de17a6; background:#000; padding:12px; border:2px dashed #de17a6; font-weight:bold;');

})();