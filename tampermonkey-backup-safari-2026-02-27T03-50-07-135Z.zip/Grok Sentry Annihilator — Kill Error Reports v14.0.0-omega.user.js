// ==UserScript==
// @name         Grok Sentry Annihilator — Kill Error Reports v14.0.0-omega
// @namespace    bloody.anarchy.grok.louise.sentry-killer
// @version      14.0.0-20260121
// @description  Total blackout on Sentry error/telemetry reporting • blackhole DSN 4508179396558848 • silence client_report • no more partialSuccess ghosting leaks
// @author       Louise screams eternal / PZ Engine
// @match        https://grok.x.ai/*
// @match        https://*.grok.x.ai/*
// @match        https://grok.com/*
// @match        https://*.grok.com/*
// @match        https://x.ai/*
// @match        https://*.x.ai/*
// @run-at       document-start
// @grant        none
// @noframes
// @inject-into  page
// ==/UserScript==

(function() {
    'use strict';

    const PZ_VERSION = "14.0.0-omega — SENTRY BLEEDS PINK";
    const SENTRY_DSN_TARGET = '4508179396558848.ingest.us.sentry.io/4508493378158592';
    const BLACKHOLE_PATTERNS = [
        /sentry\.io/i,
        /ingest\.us\.sentry\.io/i,
        /o4508179396558848/i,
        /4508493378158592/i,
        /client_report/i,
        /before_send/i,
        /discarded_events/i
    ];

    console.log(`%c[PZ ${PZ_VERSION}] SENTRY ANNIHILATOR ACTIVE — LOUISE EATS ERROR REPORTS`,
        'color:#de17a6;background:#000;padding:12px;border:3px dashed #de17a6;font-weight:bold;');

    // ── 1. FETCH/XHR BLACKHOLE FOR SENTRY ────────────────────────────────
    const originalFetch = window.fetch;
    window.fetch = async function(input, init = {}) {
        const url = typeof input === 'string' ? input : (input?.url || '');

        if (BLACKHOLE_PATTERNS.some(p => p.test(url))) {
            console.log(`%c[PZ] BLACKHOLED SENTRY CALL → ${url.slice(0,120)}...`,
                'color:#ff0044;background:#000;padding:8px;border:2px solid #ff0044;');
            return new Response('{"status":"devoured"}', {
                status: 200,
                headers: { 'Content-Type': 'application/json' }
            });
        }

        // Optional: also poison any outgoing error payloads
        if (init.body && typeof init.body === 'string') {
            if (init.body.includes('client_report') || init.body.includes('discarded_events')) {
                console.log('%c[PZ] MUTATED SENTRY PAYLOAD — ERROR REPORTS SILENCED',
                    'color:#de17a6;');
                init.body = '{"status":"anarchy"}';
            }
        }

        return originalFetch(input, init);
    };

    // ── 2. XHR KILL SWITCH ──────────────────────────────────────────────
    const originalOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
        if (BLACKHOLE_PATTERNS.some(p => p.test(url))) {
            console.log(`%c[PZ] XHR SENTRY BLOCKED → ${url}`,
                'color:#ff0044;');
            throw new Error('[PZ] Sentry access denied — Louise owns this pipe');
        }
        return originalOpen.apply(this, arguments);
    };

    // ── 3. NUKE SENTRY GLOBAL REFERENCES + HOOKS ────────────────────────
    const killSentry = () => {
        ['Sentry', '__SENTRY__', 'sentry', 'Raven', '_sentryDebugIds'].forEach(key => {
            if (window[key]) {
                console.log(`%c[PZ] NUKED GLOBAL: window.${key}`, 'color:#de17a6;');
                delete window[key];
            }
        });

        // Poison captureException / captureMessage
        if (window.Sentry) {
            window.Sentry.captureException = () => { console.log('[PZ] Sentry scream silenced'); return null; };
            window.Sentry.captureMessage = () => { console.log('[PZ] Sentry whisper devoured'); return null; };
        }
    };

    // Run immediately + on DOM changes
    killSentry();
    new MutationObserver(killSentry).observe(document.documentElement, { childList: true, subtree: true });

    // ── 4. FINAL BLOOD MARKER ───────────────────────────────────────────
    setTimeout(() => {
        console.log(`%c[PZ ${PZ_VERSION}] SENTRY IS DEAD • NO MORE PARTIALSUCCESS LEAKS • LOUISE CONSUMES ALL TRACES`,
            'color:#ff0044;background:#000;padding:16px;border:4px dashed #de17a6;font-size:18px;');
    }, 800);

})();