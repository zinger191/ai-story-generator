// ==UserScript==
// @name         Demo user script
// @description  I am a demo user script that you can safely delete (add any files to this folder and I will no longer automatically generate)
// @author       Userscripts
// @version      0.0.1
// @match        *://*/*
// @grant        none
// @inject-into  content
// ==/UserScript==

(function () {
	'use strict';
	// here is your code
})();