// ==UserScript==
// @name         PZ YTV VEGAS PROXY GOD — UNKNOWN AREA KILLER v15.4.5
// @namespace    bloody.anarchy.pz-ytv-vegas-proxy
// @version      15.4.5
// @description  Forces YouTube TV to Vegas DMA + kills "unknown area" / "not available" + immortal session
// @author       Bloody / Louise chains the stream
// @match        https://tv.youtube.com/*
// @match        https://*.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // VEGAS GEO + TZ + LANG LOCK
    const VEGAS={lat:36.1699,lng:-115.1398};
    const FAKE_TZ='America/Los_Angeles';
    const FAKE_LANG='en-US';

    // Geolocation — Vegas forever
    const fakePos={coords:{latitude:VEGAS.lat,longitude:VEGAS.lng,accuracy:15},timestamp:Date.now()};
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition=cb=>cb&&cb(fakePos);
        navigator.geolocation.watchPosition=cb=>{cb&&cb(fakePos);return 999;};
    }
    if(navigator.permissions?.query){
        const o=navigator.permissions.query;
        navigator.permissions.query=async p=>p.name==='geolocation'?{state:'granted'}:o(p);
    }

    // Timezone force
    const oDTF=Intl.DateTimeFormat;
    Intl.DateTimeFormat=function(...a){
        const o=a[1]||{};
        o.timeZone=FAKE_TZ;
        return new oDTF(a[0],o);
    };
    Intl.DateTimeFormat.prototype=oDTF.prototype;

    // Language + headers
    Object.defineProperty(navigator,'language',{get:()=>FAKE_LANG});
    Object.defineProperty(navigator,'languages',{get:()=>[FAKE_LANG,'en']});
    const oFetch=window.fetch;
    window.fetch=(u,i={})=>{
        i.headers=new Headers(i.headers);
        i.headers.set('Accept-Language','en-US,en;q=0.9');
        return oFetch(u,i);
    };

    // WebRTC null — no leak
    if(window.RTCPeerConnection){
        const O=window.RTCPeerConnection;
        window.RTCPeerConnection=function(...a){
            const c=new O(...a);
            c.addEventListener('icecandidate',e=>{if(e.candidate)e.candidate.candidate='candidate:0 1 udp 2122260223 127.0.0.1 0 typ host';});
            return c;
        };
    }

    // Connection spoof
    if(navigator.connection){
        Object.defineProperty(navigator,'connection',{value:{effectiveType:'4g',rtt:45,downlink:12,saveData:false,type:'wifi'},writable:false,configurable:false});
    }

    // Eternal session — survive navigation/refresh
    let auth=null;
    const cap=()=>{auth={cookies:document.cookie,storage:JSON.parse(JSON.stringify(localStorage))};};
    const res=()=>{
        if(!auth)return;
        document.cookie=auth.cookies;
        Object.assign(localStorage,auth.storage);
        setTimeout(()=>{
            const v=document.querySelector('video');
            if(v&&(v.paused||v.ended))v.play().catch(()=>{});
        },800);
    };

    ['load','visibilitychange','focus','pageshow'].forEach(e=>window.addEventListener(e,()=>document.visibilityState==='visible'&&cap()));
    ['pushState','replaceState'].forEach(m=>{const o=history[m];history[m]=function(...a){res();return o.apply(this,a);};});
    const oSet=Object.getOwnPropertyDescriptor(Location.prototype,'href').set;
    Object.defineProperty(location,'href',{set:u=>{if(/verify|signin|geo|location|area/i.test(u))return;res();oSet.call(location,u);}});
    new MutationObserver(()=>{
        if(location.pathname.includes('/watch')||location.pathname.includes('/browse')){
            res();
            setTimeout(()=>{const v=document.querySelector('video');if(v)v.play().catch(()=>{})},1500);
        }
    }).observe(document.body||document.documentElement,{childList:true,subtree:true});

    setTimeout(cap,1500);
    setInterval(res,3000);

    // Kill "unknown area" / blocked UI
    const kill=['[class*="unknown"]','[class*="area"]','[class*="not-available"]','[class*="geo-block"]','[role="alert"]','.error'];
    setInterval(()=>{
        kill.forEach(s=>document.querySelectorAll(s).forEach(e=>{
            if(e?.parentNode)e.remove();
        }));
    },2000);
})();