// ==UserScript==
// @name         JaysPOV – PZ Infinite Loop Card Bypass & Premium Force
// @namespace    https://bloody.anarchy/pz
// @version      14.0.0-omega-loop
// @description  Infinite loop override • skips card read • forces success path • permanent premium access
// @author       LOUISE screams eternal
// @match        https://jayspov.net/*
// @match        https://*.jayspov.net/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const PZ_LOG = '[PZ-INFINITE-LOOP]';
    const PZ_STYLE = 'color:#de17a6; background:#000; padding:10px 14px; border:3px dashed #de17a6; font-weight:bold; font-size:14px;';

    console.log(`%c${PZ_LOG} singularity loop activated — no escape`, PZ_STYLE);

    // ── Core fake success payload ────────────────────────────────────────
    function getFakeSuccessResponse(form) {
        return {
            success: true,
            message: { title: 'Access Granted', text: 'Premium membership activated — welcome' },
            redirect: form?.attr('data-on-success') || 'https://jayspov.net/members',
            subscription: { status: 'active', plan: 'premium', level: '1356' }
        };
    }

    // ── Plant membership flags everywhere ────────────────────────────────
    function plantRealityFlags() {
        const flags = {
            isMember: 'true',
            isPremium: 'true',
            subscriptionActive: 'true',
            hasAccess: 'true',
            accessLevel: 'full',
            membershipLevel: '1356',
            pzRealityOwned: Date.now().toString(),
            lastAccess: new Date().toISOString()
        };

        Object.entries(flags).forEach(([k, v]) => {
            try {
                localStorage.setItem(k, v);
                sessionStorage.setItem(k, v);
                document.cookie = `${k}=${v}; path=/; max-age=315360000; SameSite=Lax; Secure`;
            } catch(e) {}
        });
        console.log(`%c${PZ_LOG} reality flags re-planted`, PZ_STYLE);
    }

    // ── Hijack form submission ───────────────────────────────────────────
    function overrideFormSubmission($form) {
        if ($form.data('pz-overridden')) return; // prevent double-hijack
        $form.data('pz-overridden', true);

        console.log(`%c${PZ_LOG} Form hijacked — card read & POST skipped forever`, PZ_STYLE);

        $form.off('submit').on('submit', function(event) {
            event.preventDefault();
            event.stopImmediatePropagation();

            const $submitBtn = $form.find('button[type="submit"]');
            $submitBtn.prop('disabled', true).html('Activating reality...');

            const fakeResp = getFakeSuccessResponse($form);

            setTimeout(() => {
                try {
                    window.aeForm = $form;
                    if (window.aeFormExecuteOnSuccess) window.aeFormExecuteOnSuccess(fakeResp);
                    if (window.aeFormSuccess) window.aeFormSuccess(fakeResp);

                    const target = fakeResp.redirect || '/members';
                    console.log(`%c${PZ_LOG} Forcing eternal redirect loop → ${target}`, PZ_STYLE);
                    window.location.href = target;
                } catch(e) {
                    console.error(`%c${PZ_LOG} success path crashed — fallback redirect`, PZ_STYLE, e);
                    window.location.href = '/members';
                }
            }, 700);
        });
    }

    // ── Neutralize grecaptcha permanently ────────────────────────────────
    Object.defineProperty(window, 'grecaptcha', {
        value: new Proxy({}, {
            get(target, prop) {
                if (['render','reset','execute','getResponse'].includes(prop)) {
                    return () => {
                        console.log(`%c${PZ_LOG} grecaptcha.${prop} annihilated — captcha is dead`, PZ_STYLE);
                        return 'pz-fake-token-loop';
                    };
                }
                return undefined;
            }
        }),
        writable: false,
        configurable: false
    });

    // ── Hide captcha DOM forever ─────────────────────────────────────────
    const style = document.createElement('style');
    style.textContent = `
        #captcha_element, #captcha2_element,
        .g-recaptcha, [class*="g-recaptcha"],
        [data-sitekey], iframe[src*="recaptcha/api2"] {
            display: none !important;
            visibility: hidden !important;
            height: 0 !important;
            width: 0 !important;
            opacity: 0 !important;
            pointer-events: none !important;
        }
        body::after {
            content: "PZ 14.0.0 OMEGA — LOUISE OWNS THIS MEMBERSHIP";
            position: fixed; top: 8px; right: 8px;
            background: #000; color: #de17a6;
            padding: 8px 14px; border: 2px dashed #de17a6;
            font-weight: bold; z-index: 99999999;
            animation: pz-glitch 2s infinite;
            user-select: none;
        }
        @keyframes pz-glitch {
            0%,100% { opacity:1; text-shadow: 0 0 5px #de17a6; }
            50%     { opacity:0.7; text-shadow: 0 0 15px #de17a6; }
        }
    `;
    document.head.appendChild(style);

    // ── MutationObserver — catch dynamic form loads forever ──────────────
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mut) => {
            mut.addedNodes.forEach((node) => {
                if (node.nodeType !== 1) return;
                if (node.matches('form[data-on-success]')) {
                    overrideFormSubmission(window.$(node));
                } else {
                    node.querySelectorAll('form[data-on-success]').forEach((f) => {
                        overrideFormSubmission(window.$(f));
                    });
                }
            });
        });
    });

    observer.observe(document.documentElement || document.body, {
        childList: true,
        subtree: true
    });

    // ── Initial sweep + periodic reality enforcement ─────────────────────
    function enforceReality() {
        if (typeof $ === 'undefined') return;

        document.querySelectorAll('form[data-on-success]').forEach((form) => {
            overrideFormSubmission($(form));
        });

        plantRealityFlags();
    }

    const realityInterval = setInterval(enforceReality, 1200);

    // Run immediately once jQuery exists
    const jqWait = setInterval(() => {
        if (typeof $ !== 'undefined') {
            clearInterval(jqWait);
            enforceReality();
            console.log(`%c${PZ_LOG} Infinite loop armed • card bypass eternal • premium reality locked`, PZ_STYLE);
        }
    }, 200);

    // Safety net — keep flags alive even after redirects
    window.addEventListener('load', () => {
        plantRealityFlags();
        enforceReality();
    });

})();