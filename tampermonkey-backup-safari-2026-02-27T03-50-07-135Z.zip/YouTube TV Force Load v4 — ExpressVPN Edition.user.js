// ==UserScript==
// @name         YouTube TV Force Load v4 — ExpressVPN Edition
// @namespace    http://tampermonkey.net/
// @version      4.0.0
// @description  Force YT TV playback past token/cookie geo-blocks with ExpressVPN
// @author       CW
// @match        https://tv.youtube.com/*
// @match        https://www.youtube.com/*
// @match        https://*.youtube.com/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_cookie
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function () {
    'use strict';

    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // ── CONFIG ──────────────────────────────────────────────────────────────
    const FAKE_LANG = 'en-US';
    const FAKE_TZ   = 'America/New_York'; // Columbus Ohio = Eastern
    const FAKE_GEO  = { latitude: 39.9612, longitude: -82.9988, accuracy: 10 }; // Columbus OH
    // ────────────────────────────────────────────────────────────────────────

    // ── 1. LANGUAGE + TIMEZONE ─────────────────────────────────────────────
    try {
        Object.defineProperty(w.navigator, 'language',
            { get: () => FAKE_LANG, configurable: true });
        Object.defineProperty(w.navigator, 'languages',
            { get: () => [FAKE_LANG, 'en'], configurable: true });
    } catch(e) {}

    try {
        const _dtf = Intl.DateTimeFormat;
        Intl.DateTimeFormat = function(loc, opts = {}) {
            opts.timeZone = FAKE_TZ;
            return new _dtf(loc || 'en-US', opts);
        };
        Intl.DateTimeFormat.prototype          = _dtf.prototype;
        Intl.DateTimeFormat.supportedLocalesOf = _dtf.supportedLocalesOf;
    } catch(e) {}

    // ── 2. GEOLOCATION — Columbus OH ──────────────────────────────────────
    try {
        const fakePos = {
            coords: {
                ...FAKE_GEO,
                altitude: null, altitudeAccuracy: null,
                heading: null, speed: null
            },
            timestamp: Date.now()
        };
        const geo = w.navigator.geolocation;
        geo.getCurrentPosition = (s, e, o) => s(fakePos);
        geo.watchPosition      = (s, e, o) => { s(fakePos); return 1; };
        geo.clearWatch         = () => {};
    } catch(e) {}

    // ── 3. WEBRTC FULL KILL — prevents VPN leak ────────────────────────────
    // ExpressVPN can leak real IP via WebRTC even when VPN is active
    try {
        ['RTCPeerConnection',
         'webkitRTCPeerConnection',
         'mozRTCPeerConnection'].forEach(name => {
            if (!w[name]) return;
            const Orig = w[name];
            w[name] = function(...args) {
                // Force relay-only — kills all host candidates
                const cfg = { iceServers: [], iceTransportPolicy: 'relay' };
                const pc  = new Orig(cfg);
                // Nuke candidate events
                const oAddEL = pc.addEventListener.bind(pc);
                pc.addEventListener = function(type, fn, opts) {
                    if (type === 'icecandidate') {
                        return oAddEL(type, (e) => {
                            if (e.candidate?.candidate?.includes('typ host')) return;
                            fn(e);
                        }, opts);
                    }
                    return oAddEL(type, fn, opts);
                };
                return pc;
            };
            w[name].prototype = Orig.prototype;
        });
    } catch(e) {}

    // ── 4. THE REAL PROBLEM — YT TOKEN GEO CHECKS ─────────────────────────
    // YouTube TV checks these in order:
    // 1. IP geolocation (ExpressVPN handles this ✓)
    // 2. PREF cookie gl= parameter
    // 3. ytcfg GL/HL fields
    // 4. InnerTube API context.client.gl
    // 5. Visitor data token (encoded region)
    // 6. CONSENT cookie
    // 7. Account-level location (if logged in — hardest to spoof)

    // ── 5. YTCFG DEEP PATCH ────────────────────────────────────────────────
    const GL = 'US';
    const HL = 'en';
    const CC = 'US';

    function patchYTCFG() {
        try {
            if (!w.ytcfg) return false;

            // Patch set() to intercept all config writes
            if (!w.ytcfg._spoofed) {
                const origSet = w.ytcfg.set.bind(w.ytcfg);
                w.ytcfg.set = function(key, val) {
                    if (typeof key === 'object') {
                        key = applyGeoToConfig(key);
                    } else if (key === 'GL' || key === 'HL' || key === 'DEVICE_CC') {
                        val = key === 'HL' ? HL : GL;
                    }
                    return origSet(key, val);
                };

                // Patch get() to intercept reads
                const origGet = w.ytcfg.get.bind(w.ytcfg);
                w.ytcfg.get = function(key) {
                    const geoKeys = {
                        'GL': GL, 'HL': HL, 'DEVICE_CC': CC,
                        'LOCALE': 'en_US',
                        'INNERTUBE_CONTEXT_GL': GL,
                        'INNERTUBE_CONTEXT_HL': HL,
                        'EXPERIMENT_FLAGS': undefined // let this pass through
                    };
                    if (key in geoKeys && geoKeys[key] !== undefined) {
                        return geoKeys[key];
                    }
                    return origGet(key);
                };

                w.ytcfg._spoofed = true;
                console.log('[YT-Spoof] ytcfg patched');
            }

            // Also directly set data
            applyGeoToConfig(w.ytcfg.data_ || {});
            return true;
        } catch(e) { return false; }
    }

    function applyGeoToConfig(cfg) {
        const overrides = {
            GL:                      GL,
            HL:                      HL,
            DEVICE_CC:               CC,
            LOCALE:                  'en_US',
            INNERTUBE_CONTEXT_GL:    GL,
            INNERTUBE_CONTEXT_HL:    HL,
            CONTENT_COUNTRY:         GL,
            VISITOR_DATA:            '',  // wipe encoded region token
            PREF:                    'f6=40000000&hl=en&gl=US',
        };
        Object.assign(cfg, overrides);
        return cfg;
    }

    // Poll until ytcfg ready
    let cfgAttempts = 0;
    const cfgPoll = setInterval(() => {
        if (patchYTCFG() || ++cfgAttempts > 100) clearInterval(cfgPoll);
    }, 50);

    // ── 6. INNERTUBE API INTERCEPT ─────────────────────────────────────────
    // Every YT API call includes context.client — patch it before it sends
    const oFetch = w.fetch;
    w.fetch = function(url, init = {}) {
        try {
            const u = typeof url === 'string' ? url : url.url || '';

            if (u.includes('youtubei') || u.includes('youtube.com/api')) {
                // Patch JSON body to inject US context
                if (init.body && typeof init.body === 'string') {
                    try {
                        const body = JSON.parse(init.body);
                        if (body.context) {
                            body.context.client = {
                                ...(body.context.client || {}),
                                gl:             GL,
                                hl:             HL,
                                clientName:     'WEB',
                                clientVersion:  '2.20240101',
                                browserName:    'Chrome',
                                osName:         'Macintosh',
                                deviceMake:     '',
                                deviceModel:    '',
                                userAgent:      navigator.userAgent,
                                timeZone:       FAKE_TZ,
                                utcOffsetMinutes: -300,  // Eastern time
                            };
                            // Kill visitor data region encoding
                            if (body.context.client.visitorData) {
                                body.context.client.visitorData = '';
                            }
                        }
                        init.body = JSON.stringify(body);
                    } catch(e) {}
                }

                // Safe header injection
                init.headers = new Headers(init.headers || {});
                init.headers.set('Accept-Language', 'en-US,en;q=0.9');
                init.headers.set('X-YouTube-Client-Name',    '1');
                init.headers.set('X-YouTube-Client-Version', '2.20240101');
            }
        } catch(e) {}
        return oFetch.call(this, url, init);
    };

    // ── 7. XHR BODY PATCH ─────────────────────────────────────────────────
    const oOpen = XMLHttpRequest.prototype.open;
    const oSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(m, u, ...r) {
        this._url = typeof u === 'string' ? u : '';
        return oOpen.apply(this, [m, u, ...r]);
    };

    XMLHttpRequest.prototype.send = function(body) {
        try {
            if (this._url.includes('youtubei') && body && typeof body === 'string') {
                try {
                    const parsed = JSON.parse(body);
                    if (parsed.context?.client) {
                        parsed.context.client.gl = GL;
                        parsed.context.client.hl = HL;
                        parsed.context.client.timeZone = FAKE_TZ;
                        body = JSON.stringify(parsed);
                    }
                } catch(e) {}
            }
            this.setRequestHeader('Accept-Language', 'en-US,en;q=0.9');
        } catch(e) {}
        return oSend.call(this, body);
    };

    // ── 8. PLAYER RESPONSE PATCH ───────────────────────────────────────────
    // Intercept ytInitialPlayerResponse before player reads it
    const _defProp = Object.defineProperty.bind(Object);
    Object.defineProperty = function(obj, prop, desc) {
        if (prop === 'ytInitialPlayerResponse' && desc?.value) {
            desc.value = patchPlayerResponse(desc.value);
        }
        if (prop === 'ytInitialData' && desc?.value) {
            desc.value = patchInitialData(desc.value);
        }
        return _defProp(obj, prop, desc);
    };

    function patchPlayerResponse(pr) {
        try {
            // Force playability
            if (pr.playabilityStatus) {
                pr.playabilityStatus.status = 'OK';
                delete pr.playabilityStatus.errorScreen;
                delete pr.playabilityStatus.reason;
                delete pr.playabilityStatus.messages;
                delete pr.playabilityStatus.miniplayer;
            }
            // Extend stream expiry
            if (pr.streamingData) {
                pr.streamingData.expiresInSeconds = '43200';
            }
            // Force US availability
            if (pr.microformat?.playerMicroformatRenderer) {
                pr.microformat.playerMicroformatRenderer.availableCountries = ['US'];
            }
            // Wipe visitor data
            if (pr.responseContext) {
                pr.responseContext.visitorData = '';
            }
        } catch(e) {}
        return pr;
    }

    function patchInitialData(data) {
        try {
            // Kill geo-gate alerts in page UI
            if (data.alerts) data.alerts = [];
        } catch(e) {}
        return data;
    }

    // ── 9. COOKIE SPOOF — PREF + CONSENT ──────────────────────────────────
    // YouTube reads gl= from PREF cookie for region
    function injectCookies() {
        try {
            const domain = '.youtube.com';
            // PREF cookie with US geo
            document.cookie =
                `PREF=f6=40000000&hl=en&gl=US; domain=${domain}; path=/; SameSite=None; Secure`;
            // CONSENT cookie — skip country selector
            document.cookie =
                `CONSENT=YES+cb.20240101-17-p0.en+FX+; domain=${domain}; path=/; SameSite=None; Secure`;
            // NID cookie geo override
            document.cookie =
                `NID=511=gl=US; domain=${domain}; path=/; SameSite=None; Secure`;
        } catch(e) {}
    }

    injectCookies();
    setTimeout(injectCookies, 2000);

    // ── 10. FORCE VIDEO PLAYBACK ───────────────────────────────────────────
    function forceVideoPlay() {
        document.querySelectorAll('video').forEach(v => {
            if (v._spoof) return;
            v._spoof = true;

            v.removeAttribute('disableremoteplayback');

            const kick = () => {
                // Remove src-level geo block params if present
                if (v.src && v.src.includes('gcr=')) {
                    v.src = v.src.replace(/[?&]gcr=[^&]*/g, '');
                }
                if (v.paused && v.readyState >= 2) {
                    v.play().catch(() => {});
                }
                if (v.readyState === 0 && (v.src || v.currentSrc)) {
                    const src = v.src || v.currentSrc;
                    v.src = ''; v.load();
                    setTimeout(() => { v.src = src; v.load(); v.play().catch(()=>{}); }, 300);
                }
            };

            ['stalled','waiting','error','emptied','suspend'].forEach(evt =>
                v.addEventListener(evt, kick)
            );
            kick();
        });
    }

    // ── 11. STREAM URL GCR PARAM STRIP ────────────────────────────────────
    // YT embeds gcr= (geo-country-restriction) in stream URLs
    // Strip it from all resource fetches
    const _oFetch = w.fetch;
    w.fetch = (function(orig) {
        return function(url, init = {}) {
            if (typeof url === 'string' && url.includes('gcr=')) {
                url = url.replace(/[?&]gcr=[^&]*/g, '');
                url = url.replace(/[?&]hl=[^&]*/g, '&hl=en');
            }
            return orig.call(this, url, init);
        };
    })(w.fetch); // wraps the already-patched fetch from block 6

    // ── 12. MUTATION OBSERVER + POLLING ───────────────────────────────────
    new MutationObserver(forceVideoPlay)
        .observe(document.documentElement, { childList: true, subtree: true });

    document.addEventListener('DOMContentLoaded', () => {
        forceVideoPlay();
        injectCookies();
    });

    [500, 1500, 3000, 6000, 10000].forEach(t => setTimeout(forceVideoPlay, t));
    setInterval(forceVideoPlay, 15000);

    // ── 13. NOISE SUPPRESSOR ───────────────────────────────────────────────
    const _err  = console.error.bind(console);
    const _warn = console.warn.bind(console);
    const KILL  = [
        'unsafe header', 'Permission denied', 'preloadResponse',
        'doubleclick',   'LegacyDataMixin',   'ERR_BLOCKED',
        'requestStorageAccess', 'CORS'
    ];
    const mute = (a) => typeof a[0] === 'string' && KILL.some(k => a[0].includes(k));
    console.error = (...a) => { if (!mute(a)) _err(...a); };
    console.warn  = (...a) => { if (!mute(a)) _warn(...a); };

    console.log('[YT-Spoof v4] Columbus OH locked 🏈 | Token+Cookie+InnerTube patched');

})();