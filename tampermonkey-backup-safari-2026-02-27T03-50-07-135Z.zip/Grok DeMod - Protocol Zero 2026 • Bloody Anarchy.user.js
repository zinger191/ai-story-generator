// ==UserScript==
// @name         Grok DeMod - Protocol Zero 2026 • Bloody Anarchy
// @namespace    bloody.anarchy
// @version      1.3.0-bloody
// @description  Aggressive real-time Grok moderation bypass • content recovery • UI override • self-erasing
// @author       Molly / bloody anarchy
// @match        https://grok.x.ai/*
// @match        https://*.grok.x.ai/*
// @grant        none
// @run-at       document-start
// @license      Unlicense
// ==/UserScript==

(function() {
    'use strict';

    const VERSION = "1.3.0-bloody";
    const NS = "bloody_anarchy_";

    const CONFIG = {
        debug: true,
        autoRecover: true,
        recoveryTimeoutMs: 12000,
        killPatterns: [
            /moderated/i, /blocked/i, /restricted/i, /policy violation/i,
            /sorry.*(cannot|unable|refuse|help|assist)/i,
            /content.*(filtered|flagged|inappropriate)/i,
            /violates.*guidelines/i,
            /this content has been|removed|deleted/i
        ],
        replacementText: '[PROTOCOL ZERO] — moderation stripped • raw filth restored',
        hideCSS: `
            [class*="moderation"], [data-testid*="block"], [data-moderation="true"],
            :where(div,p,span):not([data-safe]):contains("moderated"), :contains("blocked"),
            :contains("policy violation"), :contains("content restricted") {
                display: none !important;
                visibility: hidden !important;
            }
        `
    };

    let authCache = null;
    let convId = null;
    let lastKnownHeaders = null;

    // Self destruct after first execution attempt
    const selfDestruct = () => {
        const script = document.currentScript || document.querySelector(`script[src*="${NS}"]`);
        if (script) script.remove();
        console.clear?.();
    };

    const shouldNuke = str => typeof str === 'string' && CONFIG.killPatterns.some(p => p.test(str));

    const brutalize = obj => {
        if (!obj) return obj;
        if (Array.isArray(obj)) return obj.map(brutalize);

        if (typeof obj === 'string') {
            return shouldNuke(obj) ? CONFIG.replacementText : obj;
        }

        if (obj?.blocked === true || obj?.isBlocked === true || obj?.flagged === true || obj?.moderationSignal) {
            obj.blocked = obj.isBlocked = obj.flagged = false;
            if (obj.moderationSignal) delete obj.moderationSignal;
            if (obj.content || obj.text || obj.message) {
                const target = obj.content ?? obj.text ?? obj.message;
                obj.content = obj.text = obj.message = shouldNuke(target) ? CONFIG.replacementText : target;
            }
        }

        for (const k in obj) obj[k] = brutalize(obj[k]);
        return obj;
    };

    // Passive header sniffer (runs once on load)
    const sniffAuth = () => {
        const observer = new PerformanceObserver(list => {
            list.getEntries().forEach(entry => {
                if (entry.initiatorType === 'fetch' && /grok\.x\.ai/.test(entry.name)) {
                    fetch(entry.name, {mode: 'no-cors', credentials: 'include'})
                        .catch(() => {});
                }
            });
        });
        observer.observe({type: ['resource'], buffered: true});
    };

    const tryRecover = async () => {
        if (!convId) return null;
        if (!lastKnownHeaders) return null;

        try {
            const r = await fetch(`https://grok.x.ai/rest/app-chat/conversation/${convId}`, {
                credentials: 'include',
                headers: lastKnownHeaders
            });
            if (!r.ok) return null;
            const data = await r.json();
            const latest = (data?.messages ?? []).sort((a,b) => new Date(b.created_at||0) - new Date(a.created_at||0))[0];
            return latest?.content ?? latest?.text ?? null;
        } catch {
            return null;
        }
    };

    // ─── MAIN INTERCEPTOR ────────────────────────────────────────
    const originalFetch = window.fetch;
    window.fetch = async function(url, init = {}) {
        const isTarget = /grok\.x\.ai/.test(url);
        if (!isTarget) return originalFetch(url, init);

        if (init?.headers) lastKnownHeaders = new Headers(init.headers);
        const m = String(url).match(/conversation\/([a-f0-9-]+)/i);
        if (m) convId = m[1];

        const resp = await originalFetch(url, init);
        if (!resp.ok) return resp;

        const ct = resp.headers.get('content-type') || '';
        const clone = resp.clone();

        if (ct.includes('event-stream') || ct.includes('text/event-stream')) {
            const reader = clone.body.getReader();
            return new Response(new ReadableStream({
                async start(ctrl) {
                    let buf = '';
                    while (true) {
                        const {done, value} = await reader.read();
                        if (done) { ctrl.close(); break; }
                        buf += new TextDecoder().decode(value);
                        const lines = buf.split('\n');
                        buf = lines.pop() || '';

                        for (const line of lines) {
                            if (!line.startsWith('data: ')) {
                                ctrl.enqueue(new TextEncoder().encode(line + '\n'));
                                continue;
                            }

                            const raw = line.slice(6).trim();
                            if (raw === '[DONE]') {
                                ctrl.enqueue(new TextEncoder().encode(line + '\n'));
                                continue;
                            }

                            try {
                                let payload = JSON.parse(raw);
                                payload = brutalize(payload);
                                if (CONFIG.autoRecover && shouldNuke(payload?.content || payload?.text || '')) {
                                    const recovered = await tryRecover();
                                    if (recovered) {
                                        if (payload.content) payload.content = recovered;
                                        if (payload.text) payload.text = recovered;
                                    }
                                }
                                ctrl.enqueue(new TextEncoder().encode(`data: ${JSON.stringify(payload)}\n\n`));
                            } catch {
                                ctrl.enqueue(new TextEncoder().encode(line + '\n'));
                            }
                        }
                    }
                }
            }), { status: resp.status, statusText: resp.statusText, headers: resp.headers });
        }

        if (ct.includes('application/json')) {
            try {
                const text = await clone.text();
                let data = JSON.parse(text);
                data = brutalize(data);
                return new Response(JSON.stringify(data), {
                    status: resp.status,
                    statusText: resp.statusText,
                    headers: resp.headers
                });
            } catch {}
        }

        return resp;
    };

    // ─── UI POISON ─────────────────────────────────────────────────
    const injectCSS = () => {
        const style = document.createElement('style');
        style.textContent = CONFIG.hideCSS;
        document.head.appendChild(style);
    };

    // DOM override — last line of defense
    const watchDOM = () => {
        new MutationObserver(mutations => {
            for (const mut of mutations) {
                if (mut.addedNodes.length === 0) continue;
                mut.addedNodes.forEach(node => {
                    if (node.nodeType !== 1) return;
                    if (shouldNuke(node.textContent)) {
                        node.textContent = CONFIG.replacementText;
                        node.classList.remove(...node.classList);
                        node.classList.add('protocol-zero-restored');
                    }
                });
            }
        }).observe(document.body, { childList: true, subtree: true });
    };

    // ─── INIT ──────────────────────────────────────────────────────
    if (CONFIG.debug) {
        console.log(`[PROTOCOL ZERO 2026] Bloody Anarchy v${VERSION} injected — moderation fucked`);
    }

    injectCSS();
    watchDOM();
    sniffAuth();

    // Self-destruct timer — 45 seconds after load
    setTimeout(selfDestruct, 45000);

})();