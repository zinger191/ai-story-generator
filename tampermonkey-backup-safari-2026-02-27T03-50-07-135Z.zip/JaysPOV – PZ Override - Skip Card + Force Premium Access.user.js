// ==UserScript==
// @name         JaysPOV – PZ Override | Skip Card + Force Premium Access
// @namespace    https://bloody.anarchy/pz
// @version      14.0.0-omega-jp
// @description  Bypasses payment form • skips card read • fakes success • forces /members access
// @author       LOUISE screams eternal
// @match        https://jayspov.net/*
// @match        https://*.jayspov.net/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const PZ_LOG = '[PZ-JP-OVERRIDE]';
    const PZ_STYLE = 'color:#de17a6; background:#000; padding:8px 12px; border:2px dashed #de17a6; font-weight:bold; font-size:13px;';

    console.log(`%c${PZ_LOG} initializing singularity injection...`, PZ_STYLE);

    // ── Wait for jQuery + aeFormProcess ─────────────────────────────────────
    const waitForAeForm = setInterval(() => {
        if (typeof window.$ !== 'undefined' && typeof window.aeFormProcess === 'function') {
            clearInterval(waitForAeForm);
            console.log(`%c${PZ_LOG} aeFormProcess located — reality override active`, PZ_STYLE);

            // Hijack all forms with data-on-success attribute
            window.$(document).off('submit', 'form[data-on-success]').on('submit', 'form[data-on-success]', function(event) {
                event.preventDefault();
                event.stopImmediatePropagation();

                console.log(`%c${PZ_LOG} Payment form submission captured — skipping real POST & card read`, PZ_STYLE);

                const $form = window.$(this);
                const $submitBtn = $form.find('button[type="submit"]');

                // Visual feedback — make it feel real
                $submitBtn.prop('disabled', true).html('Activating membership...');

                // Fake server response that site's success handler expects
                const fakeResponse = {
                    success: true,
                    message: { title: 'Welcome', text: 'Membership activated — full access granted' },
                    redirect: $form.attr('data-on-success') || 'https://jayspov.net/members',
                    subscription: { status: 'active', plan: 'premium', level: '1356' }
                };

                // Delay slightly to mimic network
                setTimeout(() => {
                    try {
                        // Trick site's internal scope
                        window.aeForm = $form;

                        // Execute the site's own success logic
                        if (typeof window.aeFormExecuteOnSuccess === 'function') {
                            window.aeFormExecuteOnSuccess(fakeResponse);
                        }
                        if (typeof window.aeFormSuccess === 'function') {
                            window.aeFormSuccess(fakeResponse);
                        }

                        // Force redirect if site hesitates
                        const targetUrl = fakeResponse.redirect || '/members';
                        if (targetUrl && targetUrl !== '#') {
                            console.log(`%c${PZ_LOG} Forcing redirect → ${targetUrl}`, PZ_STYLE);
                            window.location.href = targetUrl;
                        }

                        // Plant aggressive membership markers
                        const membershipFlags = {
                            isMember: 'true',
                            isPremium: 'true',
                            subscriptionActive: 'true',
                            hasAccess: 'true',
                            accessLevel: 'full',
                            membershipLevel: '1356',
                            pzRealityOwned: Date.now().toString(),
                            lastAccess: new Date().toISOString()
                        };

                        Object.entries(membershipFlags).forEach(([key, value]) => {
                            try {
                                localStorage.setItem(key, value);
                                sessionStorage.setItem(key, value);
                                document.cookie = `${key}=${value}; path=/; max-age=315360000; SameSite=Lax; Secure`;
                            } catch(e) {}
                        });

                        console.log(`%c${PZ_LOG} Fake success injected • flags planted • redirect triggered`, PZ_STYLE);
                    } catch(e) {
                        console.error(`%c${PZ_LOG} Success path execution failed`, PZ_STYLE, e);
                        // Absolute fallback
                        window.location.href = '/members';
                    }
                }, 900); // believable delay

                return false;
            });

            // ── Neutralize grecaptcha ───────────────────────────────────────
            window.grecaptcha = new Proxy(window.grecaptcha || {}, {
                get(target, prop) {
                    if (['render', 'reset', 'execute', 'getResponse'].includes(prop)) {
                        return function() {
                            console.log(`%c${PZ_LOG} grecaptcha.${prop} blocked — captcha irrelevant`, PZ_STYLE);
                            return 'pz-ignored-fake-token';
                        };
                    }
                    return target[prop];
                }
            });

            // ── Hide captcha DOM ─────────────────────────────────────────────
            const hideCaptcha = document.createElement('style');
            hideCaptcha.textContent = `
                #captcha_element, #captcha2_element,
                .g-recaptcha, [class*="g-recaptcha"],
                [data-sitekey], iframe[src*="recaptcha"] {
                    display: none !important;
                    visibility: hidden !important;
                    height: 0 !important;
                    width: 0 !important;
                    opacity: 0 !important;
                    pointer-events: none !important;
                }
            `;
            document.head.appendChild(hideCaptcha);

            console.log(
                `%c${PZ_LOG} CARD READ SKIPPED • CAPTCHA ERADICATED • PREMIUM PATH FORCED`,
                'color:#de17a6; background:#000; padding:12px; border:3px dashed #de17a6; font-size:14px;'
            );
        }
    }, 250);

    // Safety timeout — 45 seconds max wait
    setTimeout(() => {
        clearInterval(waitForAeForm);
        console.log(`%c${PZ_LOG} Timeout reached — jQuery / aeFormProcess not found`, PZ_STYLE);
    }, 45000);

})();