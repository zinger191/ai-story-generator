// ==UserScript==
// @name         PZ YTV VEGAS ETERNAL GOD — THORDATA INJECTION v15.4.4 — CONSOLE CLEAN
// @namespace    bloody.anarchy.pz-ytv-vegas-thordata
// @version      15.4.4
// @description  Silent Las Vegas DMA spoof + Thordata proxy auth injection + immortal session + full error killer — zero console noise
// @author       Bloody / Louise owns the Strip
// @match        https://tv.youtube.com/*
// @match        https://*.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // THORDATA VEGAS CREDS — YOUR NEW NODE
    const THOR_USER = "td-customer-Zinger88-country-us-state-nevada-asn-AS6389";
    const THOR_PASS = "Coldchill77";

    // VEGAS GEO + TZ + LANG
    const VEGAS = {lat:36.1699,lng:-115.1398};
    const FAKE_TZ = 'America/Los_Angeles';
    const FAKE_LANG = 'en-US';

    // Geolocation lock
    const fakePos = {coords:{latitude:VEGAS.lat,longitude:VEGAS.lng,accuracy:15},timestamp:Date.now()};
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition=cb=>cb&&cb(fakePos);
        navigator.geolocation.watchPosition=cb=>{cb&&cb(fakePos);return 999;};
    }
    if(navigator.permissions?.query){
        const o=navigator.permissions.query;
        navigator.permissions.query=async p=>p.name==='geolocation'?{state:'granted'}:o(p);
    }

    // Timezone force
    const oDTF=Intl.DateTimeFormat;
    Intl.DateTimeFormat=function(...a){
        const o=a[1]||{};
        o.timeZone=FAKE_TZ;
        return new oDTF(a[0],o);
    };
    Intl.DateTimeFormat.prototype=oDTF.prototype;

    // Language + header force + Thordata auth injection
    Object.defineProperty(navigator,'language',{get:()=>FAKE_LANG});
    Object.defineProperty(navigator,'languages',{get:()=>[FAKE_LANG,'en']});
    const oFetch=window.fetch;
    window.fetch=(u,i={})=>{
        i.headers=new Headers(i.headers);
        i.headers.set('Accept-Language','en-US,en;q=0.9');
        // Thordata proxy auth header on YouTube requests
        if(u.includes('youtube')||u.includes('thordata')){
            const auth=btoa(`${THOR_USER}:${THOR_PASS}`);
            i.headers.set('Proxy-Authorization',`Basic ${auth}`);
        }
        return oFetch(u,i);
    };

    // WebRTC null — no IP leak
    if(window.RTCPeerConnection){
        const O=window.RTCPeerConnection;
        window.RTCPeerConnection=function(...a){
            const c=new O(...a);
            c.addEventListener('icecandidate',e=>{if(e.candidate)e.candidate.candidate='candidate:0 1 udp 2122260223 127.0.0.1 0 typ host';});
            return c;
        };
    }

    // Connection spoof — fake Vegas cable
    if(navigator.connection){
        Object.defineProperty(navigator,'connection',{value:{effectiveType:'4g',rtt:45,downlink:12,saveData:false,type:'wifi'},writable:false,configurable:false});
    }

    // Storage access grant + kill denied/preload/DoubleClick spam
    if(document.requestStorageAccess){
        document.requestStorageAccess=()=>Promise.resolve();
    }
    const oErr=console.error;
    console.error=function(...a){
        if(a[0]?.includes?.('requestStorageAccessFor')||a[0]?.includes?.('Permission denied')||
           a[0]?.includes?.('preloadResponse')||a[0]?.includes?.('googleads.g.doubleclick.net')||
           a[0]?.includes?.('LegacyDataMixin'))return;
        return oErr.apply(this,a);
    };

    // SW preload shadow — no cancel errors
    if('serviceWorker'in navigator){
        const o=navigator.serviceWorker.register;
        navigator.serviceWorker.register=function(...a){
            a[1]=a[1]||{};
            a[1].scope='/';
            return o.apply(this,a).catch(()=>{});
        };
    }

    // Eternal session god — survive navigation/refresh/tab death
    let auth=null;
    const cap=()=>{auth={cookies:document.cookie,storage:JSON.parse(JSON.stringify(localStorage))};};
    const res=()=>{
        if(!auth)return;
        document.cookie=auth.cookies;
        Object.assign(localStorage,auth.storage);
        setTimeout(()=>{
            const v=document.querySelector('video');
            if(v&&(v.paused||v.ended))v.play().catch(()=>{});
        },800);
    };

    ['load','visibilitychange','focus','pageshow'].forEach(e=>window.addEventListener(e,()=>document.visibilityState==='visible'&&cap()));
    ['pushState','replaceState'].forEach(m=>{const o=history[m];history[m]=function(...a){res();return o.apply(this,a);};});
    const oSet=Object.getOwnPropertyDescriptor(Location.prototype,'href').set;
    Object.defineProperty(location,'href',{set:u=>{if(/verify|signin|geo|location|area/i.test(u))return;res();oSet.call(location,u);}});
    new MutationObserver(()=>{
        if(location.pathname.includes('/watch')||location.pathname.includes('/browse')){
            res();
            setTimeout(()=>{
                const v=document.querySelector('video');
                if(v)v.play().catch(()=>{});
            },1500);
        }
    }).observe(document.body||document.documentElement,{childList:true,subtree:true});

    setTimeout(cap,1500);
    setInterval(res,3000);
})();