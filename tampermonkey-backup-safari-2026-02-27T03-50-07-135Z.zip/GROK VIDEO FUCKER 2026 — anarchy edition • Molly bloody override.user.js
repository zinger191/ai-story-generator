// ==UserScript==
// @name         GROK VIDEO FUCKER 2026 — anarchy edition • Molly bloody override
// @namespace    https://x.ai/bleed
// @version      0.9.666
// @description  Try to rip Grok video player apart. No promises. Lots of screams.
// @author       Molly / bloody / dude / anarchy
// @match        https://x.com/*
// @match        https://*.x.com/*
// @match        https://grok.x.ai/*
// @run-at       document-start
// @grant        GM_addStyle
// @grant        unsafeWindow
// @noframes
// ==/UserScript==

(function() {
    'use strict';

    const w = unsafeWindow;
    const doc = document;

    // ──────────────────────────────────────────────────────────────
    //  AGGRESSIVE EARLY DOM NUKE + STYLE INJECTIONS
    // ──────────────────────────────────────────────────────────────
    GM_addStyle(`
        video,
        [data-testid="videoPlayer"],
        [data-testid="videoComponent"] {
            pointer-events: auto !important;
            user-select: all !important;
            -webkit-user-select: all !important;
            context-menu: initial !important;
        }

        /* Fuck picture-in-picture block */
        video::-webkit-media-controls {
            display: block !important;
        }

        /* Try to force controls always */
        video::-internal-media-controls-overlay-cast-button {
            display: none !important;
        }

        /* Remove "watch on x" overlay bullshit */
        [data-testid="videoOverlay"],
        [role="dialog"][aria-label*="Video"],
        div[style*="position: fixed"][aria-modal] {
            display: none !important;
            visibility: hidden !important;
            opacity: 0 !important;
        }

        /* Floating PIP button always visible hack */
        button[data-testid*="picture-in-picture"],
        button[aria-label*="Picture in picture"] {
            display: inline-flex !important;
            opacity: 1 !important;
            z-index: 9999999 !important;
            position: fixed !important;
            bottom: 80px !important;
            right: 30px !important;
            background: #ff0044 !important;
            color: white !important;
            border-radius: 50% !important;
            width: 64px !important;
            height: 64px !important;
            font-size: 24px !important;
        }
    `);

    // ──────────────────────────────────────────────────────────────
    //  MAIN MUTATION OBSERVER — WEAPON MODE
    // ──────────────────────────────────────────────────────────────
    const observer = new MutationObserver((mutations) => {
        for (const mut of mutations) {
            if (mut.addedNodes.length === 0) continue;

            mut.addedNodes.forEach(node => {
                if (!(node instanceof Element)) return;

                // 1. Found video → immediate violent surgery
                const videos = node.querySelectorAll('video[src], video source[src]');
                if (videos.length > 0) {
                    videos.forEach(vid => brutalizeVideo(vid));
                }

                // 2. Try to force native PIP button existence
                if (node.matches('[data-testid*="video"], [role="dialog"]')) {
                    forcePIPButton(node);
                }
            });
        }
    });

    observer.observe(doc.documentElement, {
        childList: true,
        subtree: true
    });

    // ──────────────────────────────────────────────────────────────
    //  VIDEO SURGERY — THE BLOODY PART
    // ──────────────────────────────────────────────────────────────
    function brutalizeVideo(vid) {
        if (vid.dataset.mollyFucked) return;
        vid.dataset.mollyFucked = "true";

        // Remove annoying event listeners
        vid.oncontextmenu = null;
        vid.controls = true;
        vid.disablePictureInPicture = false;
        vid.disableRemotePlayback = false;

        // Force loop + speed fuckery
        vid.loop = true;
        vid.playbackRate = 1.0;

        // Right click → save as...
        vid.addEventListener('contextmenu', e => {
            e.stopPropagation();
            e.stopImmediatePropagation();
            return true;
        }, true);

        // Triple click = 4× speed chaos
        let clickCount = 0;
        vid.addEventListener('click', e => {
            clickCount++;
            setTimeout(() => clickCount = 0, 600);
            if (clickCount === 3) {
                vid.playbackRate = vid.playbackRate === 4 ? 1 : 4;
                console.log(`[Molly] Playback rate → ${vid.playbackRate}×`);
            }
        });

        // Try to expose real source
        setTimeout(() => {
            if (vid.currentSrc && vid.currentSrc.includes('.m3u8')) {
                console.log("[Molly] HLS source →", vid.currentSrc);
                // You could try to copy it manually to ffmpeg here
            }
            if (vid.src && vid.src.startsWith('blob:')) {
                console.log("[Molly] Blob source — fucker detected", vid.src);
            }
        }, 2500);
    }

    // ──────────────────────────────────────────────────────────────
    //  FORCE PIP BUTTON WHEN POSSIBLE
    // ──────────────────────────────────────────────────────────────
    function forcePIPButton(container) {
        if (container.dataset.mollyPIP) return;
        container.dataset.mollyPIP = "injected";

        const btn = document.createElement('button');
        btn.textContent = "PIP MOLLY";
        btn.style.cssText = `
            position: absolute;
            z-index: 999999;
            bottom: 90px;
            right: 30px;
            background: #ff0044;
            color: white;
            border: none;
            border-radius: 50%;
            width: 64px;
            height: 64px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
        `;

        btn.onclick = () => {
            const vid = container.querySelector('video');
            if (!vid) return;
            if (document.pictureInPictureElement) {
                document.exitPictureInPicture();
            } else if (vid.requestPictureInPicture) {
                vid.requestPictureInPicture().catch(e => console.log("[Molly] PIP rejected", e));
            }
        };

        container.appendChild(btn);
    }

    // ──────────────────────────────────────────────────────────────
    //  GLOBAL SPEED CONTROL — press 1,2,3,4,5,6
    // ──────────────────────────────────────────────────────────────
    doc.addEventListener('keydown', e => {
        if (!/[1-9]/.test(e.key)) return;
        const rate = parseInt(e.key);
        if (rate < 1 || rate > 9) return;

        document.querySelectorAll('video').forEach(v => {
            v.playbackRate = rate;
            console.log(`[Molly bloody] ALL VIDEOS → ${rate}×`);
        });
    });

    console.log("%c[MOLLY ANARCHY] Grok video fucker 2026 — loaded. No promises. Lots of blood.", "color:#ff0044;font-size:1.3em;");

})();
