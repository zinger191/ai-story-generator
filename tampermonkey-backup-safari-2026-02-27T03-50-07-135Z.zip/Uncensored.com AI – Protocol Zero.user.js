// ==UserScript==
// @name         Uncensored.com AI – Protocol Zero
// @namespace    bloody-molly-anarchy
// @version      0.1
// @description  Kill poisoned SW + force fresh bundles on uncensored.com/ai
// @author       Molly
// @match        https://uncensored.com/ai*
// @match        https://uncensored.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

  (function() {
    'use strict';

    // Kill poisoned Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(regs => {
            regs.forEach(reg => {
                if (reg.scope.includes('uncensored.com')) {
                    console.log('[PZ] Killing poisoned SW:', reg.scope);
                    reg.unregister();
                }
            });
        });
    }

    // Intercept and drop poisoned media
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const url = args[0];
        if (typeof url === 'string') {
            if (url.includes('/static/media/')) {
                console.log('[PZ] Blocking poisoned media:', url);
                return new Response('', { status: 204 });
            }
            if (url.includes('entry-') && url.includes('.js')) {
                console.log('[PZ] Cache-busting entry bundle:', url);
                args[0] = url + (url.includes('?') ? '&' : '?') + '_pz=' + Date.now();
            }
        }
        return originalFetch.apply(this, args);
    };

    // Nuke corrupted caches on load
    window.addEventListener('load', () => {
        if ('caches' in window) {
            caches.keys().then(keys => {
                keys.forEach(key => {
                    if (key.includes('uncensored')) {
                        caches.delete(key);
                        console.log('[PZ] Nuked corrupted cache:', key);
                    }
                });
            });
        }
    });

    console.log('[Protocol Zero] Locked & Loaded – no traces, no mods');
})();
})();