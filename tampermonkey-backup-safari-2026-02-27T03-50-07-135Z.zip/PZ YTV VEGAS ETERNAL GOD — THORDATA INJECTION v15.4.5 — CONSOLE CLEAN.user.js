// ==UserScript==
// @name         PZ YTV VEGAS ETERNAL GOD — THORDATA INJECTION v15.4.5 — CONSOLE CLEAN
// @namespace    bloody.anarchy.pz-ytv-vegas-thordata
// @version      15.4.5
// @description  Silent Las Vegas DMA spoof + Thordata residential auth header + immortal session lite + zero console noise
// @author       Bloody / Louise owns the Strip
// @match        https://tv.youtube.com/*
// @match        https://www.youtube.com/tv*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // ── THORDATA VEGAS NODE ──
    // Update these from dashboard.thordata.com (must start with td-customer-)
    const THOR_USERNAME = "td-customer-Zinger77-country-us-state-nevada"; // ← fix: add td-customer- + session flags
    const THOR_PASSWORD = "Coldchill77";                                  // ← your pass
    const PROXY_AUTH    = btoa(`${THOR_USERNAME}:${THOR_PASSWORD}`);

    // VEGAS GEO + TZ + LANG
    const VEGAS_LAT = 36.1699;
    const VEGAS_LNG = -115.1398;
    const FAKE_TZ   = 'America/Los_Angeles';
    const FAKE_LANG = 'en-US';

    // ── GEOLOCATION LOCK ──
    const fakePos = {
        coords: { latitude: VEGAS_LAT, longitude: VEGAS_LNG, accuracy: 12 },
        timestamp: Date.now()
    };

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition  = cb => cb?.(fakePos);
        navigator.geolocation.watchPosition       = (sCb, eCb) => { sCb?.(fakePos); return 666; };
    }

    if (navigator.permissions?.query) {
        const origQuery = navigator.permissions.query;
        navigator.permissions.query = async p =>
            p.name === 'geolocation' ? { state: 'granted' } : origQuery(p);
    }

    // ── TIMEZONE FORCE ──
    const OrigDTF = Intl.DateTimeFormat;
    Intl.DateTimeFormat = function(...args) {
        const opts = args[1] || {};
        opts.timeZone = FAKE_TZ;
        return new OrigDTF(args[0], opts);
    };
    Intl.DateTimeFormat.prototype = OrigDTF.prototype;

    // ── LANGUAGE + HEADERS + THORDATA PROXY-AUTH INJECTION ──
    Object.defineProperties(navigator, {
        language:  { get: () => FAKE_LANG },
        languages: { get: () => [FAKE_LANG, 'en'] }
    });

    const origFetch = window.fetch;
    window.fetch = (url, init = {}) => {
        init.headers = new Headers(init.headers);
        init.headers.set('Accept-Language', 'en-US,en;q=0.9');

        // Inject Proxy-Authorization only on relevant domains
        if (/youtube|googlevideo|ytimg|gvt1|thordata/i.test(url)) {
            init.headers.set('Proxy-Authorization', `Basic ${PROXY_AUTH}`);
        }

        return origFetch(url, init);
    };

    // ── WEBRTC MASK (minimal IP leak protection) ──
    if (window.RTCPeerConnection) {
        const OrigRTC = window.RTCPeerConnection;
        window.RTCPeerConnection = function(...args) {
            const conn = new OrigRTC(...args);
            conn.addEventListener('icecandidate', e => {
                if (e.candidate) {
                    e.candidate.candidate = 'candidate:0 1 udp 2122260223 127.0.0.1 0 typ host';
                }
            });
            return conn;
        };
    }

    // ── FAKE CONNECTION (cable-like) ──
    if (navigator.connection) {
        Object.defineProperty(navigator, 'connection', {
            value: { effectiveType: '4g', rtt: 38, downlink: 15, saveData: false, type: 'wifi' },
            writable: false, configurable: false
        });
    }

    // ── CONSOLE NOISE KILLER ──
    const origErr = console.error;
    console.error = (...args) => {
        const msg = String(args[0] || '');
        if (/requestStorageAccess|Permission denied|preloadResponse|doubleclick|LegacyDataMixin|serviceWorker/i.test(msg)) return;
        return origErr.apply(console, args);
    };

    // ── LITE ETERNAL SESSION (only on watch/browse) ──
    let lastCookies = document.cookie;
    let lastStorage = JSON.stringify(localStorage);

    function persist() {
        if (document.visibilityState !== 'visible') return;
        if (document.cookie !== lastCookies) {
            lastCookies = document.cookie;
        }
        const newStorage = JSON.stringify(localStorage);
        if (newStorage !== lastStorage) {
            lastStorage = newStorage;
        }
    }

    function restoreAndPlay() {
        if (document.cookie !== lastCookies) {
            document.cookie = lastCookies;
        }
        // minimal storage sync — avoid full JSON parse/assign loop
        setTimeout(() => {
            const video = document.querySelector('video');
            if (video && (video.paused || video.ended)) {
                video.play().catch(() => {});
            }
        }, 1200);
    }

    ['visibilitychange', 'focus', 'pageshow'].forEach(ev =>
        window.addEventListener(ev, () => document.visibilityState === 'visible' && persist())
    );

    new MutationObserver(() => {
        if (location.pathname.includes('/watch') || location.pathname.includes('/browse')) {
            restoreAndPlay();
        }
    }).observe(document.documentElement, { childList: true, subtree: true });

    setInterval(persist, 8000); // low freq → low risk
    setTimeout(persist, 1400);

    // ── BLOCK GEO/VERIFY REDIRECTS (light) ──
    const origSetHref = Object.getOwnPropertyDescriptor(Location.prototype, 'href').set;
    Object.defineProperty(location, 'href', {
        set: url => {
            if (/verify|signin|geo|location|area|kyc/i.test(url)) return;
            origSetHref.call(location, url);
        }
    });

})();