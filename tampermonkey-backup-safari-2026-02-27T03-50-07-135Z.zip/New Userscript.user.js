// ==UserScript==
// @name         New Userscript
// @namespace    http://tampermonkey.net/
// @version      2026-01-10
// @description  try to take over the world!
// @author       You
// @match        https://www.tampermonkey.net/index.php?version=5.4.1&ext=dhdg&updated=true
// @icon         https://www.google.com/s2/favicons?sz=64&domain=tampermonkey.net
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

// ==UserScript==
// @name         Uncensored.com AI – Protocol Zero (Clean Override)
// @namespace    https://violentmonkey.github.io
// @version      0.1
// @description  Force-load fresh uncorrupted bundles + kill poisoned SW
// @author       Molly
// @match        https://uncensored.com/ai*
// @match        https://uncensored.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // 1. Kill any existing Service Worker immediately (the poison)
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(regs => {
            regs.forEach(reg => {
                if (reg.scope.includes('uncensored.com')) {
                    console.log('[PZ] Killing poisoned SW:', reg.scope);
                    reg.unregister();
                }
            });
        });
    }

    // 2. Block corrupted static/media responses at fetch level
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const url = args[0];
        if (typeof url === 'string' && url.includes('/static/media/')) {
            console.log('[PZ] Blocking poisoned media:', url);
            return new Response('', { status: 204 }); // silent kill
        }
        if (url.includes('entry-') && url.includes('.js')) {
            console.log('[PZ] Protecting main bundle:', url);
            // Force fresh load with cache-bust
            if (typeof url === 'string') {
                url = url + (url.includes('?') ? '&' : '?') + '_pz=' + Date.now();
            }
        }
        return originalFetch.apply(this, args);
    };

    // 3. Nuke corrupted cache on load
    window.addEventListener('load', () => {
        if ('caches' in window) {
            caches.keys().then(keys => {
                keys.forEach(key => {
                    if (key.includes('uncensored')) {
                        caches.delete(key);
                        console.log('[PZ] Nuked corrupted cache:', key);
                    }
                });
            });
        }
    });

    console.log('[Protocol Zero] Activated – clean, no mods, no traces');
})();// Your code here...
})();