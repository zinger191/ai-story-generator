// ==UserScript==
// @name         JaysPOV – PZ Infinite Loop Card Bypass & Premium Force v2 (Silent Edition)
// @namespace    https://bloody.anarchy/pz
// @version      14.0.0-omega-silent
// @description  Infinite loop • card read skipped • captcha silenced forever • premium forced • no error spam
// @author       LOUISE screams eternal
// @match        https://jayspov.net/*
// @match        https://*.jayspov.net/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const PZ_LOG = '[PZ-SILENT-LOOP]';
    const PZ_STYLE = 'color:#de17a6; background:#000; padding:10px 14px; border:3px dashed #de17a6; font-weight:bold; font-size:14px;';

    console.log(`%c${PZ_LOG} silent singularity loop engaged — errors will be devoured`, PZ_STYLE);

    // ── Pre-emptively kill onloadCallback before recaptcha loads ──────────
    Object.defineProperty(window, 'onloadCallback', {
        get: () => function() {
            console.log(`%c${PZ_LOG} onloadCallback attempt blocked — recaptcha irrelevant`, PZ_STYLE);
        },
        set: () => {},
        configurable: false
    });

    // ── Bulletproof grecaptcha neutralization (no crashes) ────────────────
    let fakeWidgetId = 0;
    Object.defineProperty(window, 'grecaptcha', {
        value: new Proxy({}, {
            get(target, prop) {
                const fakeMethods = {
                    render: () => {
                        console.log(`%c${PZ_LOG} grecaptcha.render blocked — fake widget ${fakeWidgetId}`, PZ_STYLE);
                        return fakeWidgetId++;
                    },
                    reset: (id) => {
                        console.log(`%c${PZ_LOG} grecaptcha.reset(${id || 0}) silenced`, PZ_STYLE);
                    },
                    execute: () => Promise.resolve('pz-fake-token-silent'),
                    getResponse: () => 'pz-fake-token-silent'
                };
                return fakeMethods[prop] || (() => {
                    console.log(`%c${PZ_LOG} grecaptcha.${String(prop)} blocked`, PZ_STYLE);
                });
            }
        }),
        writable: false,
        configurable: false
    });

    // ── Suppress recaptcha internal errors globally ──────────────────────
    const originalConsoleError = console.error;
    console.error = function(...args) {
        if (/reCAPTCHA|Invalid reCAPTCHA client id|onloadCallback/i.test(args.join(' '))) {
            console.log(`%c${PZ_LOG} recaptcha error silenced →`, ...args);
            return;
        }
        originalConsoleError.apply(console, args);
    };

    // ── Core fake success payload ────────────────────────────────────────
    function getFakeSuccessResponse(form) {
        return {
            success: true,
            message: { title: 'Access Granted', text: 'Premium membership activated — welcome' },
            redirect: form?.attr('data-on-success') || 'https://jayspov.net/members',
            subscription: { status: 'active', plan: 'premium', level: '1356' }
        };
    }

    // ── Plant membership flags everywhere ────────────────────────────────
    function plantRealityFlags() {
        const flags = {
            isMember: 'true',
            isPremium: 'true',
            subscriptionActive: 'true',
            hasAccess: 'true',
            accessLevel: 'full',
            membershipLevel: '1356',
            pzRealityOwned: Date.now().toString(),
            lastAccess: new Date().toISOString()
        };
        Object.entries(flags).forEach(([k, v]) => {
            try {
                localStorage.setItem(k, v);
                sessionStorage.setItem(k, v);
                document.cookie = `${k}=${v}; path=/; max-age=315360000; SameSite=Lax; Secure`;
            } catch(e) {}
        });
    }

    // ── Hijack form submission ───────────────────────────────────────────
    function overrideFormSubmission($form) {
        if ($form.data('pz-overridden')) return;
        $form.data('pz-overridden', true);

        console.log(`%c${PZ_LOG} Form permanently hijacked — no POST, no card read`, PZ_STYLE);

        $form.off('submit').on('submit', function(event) {
            event.preventDefault();
            event.stopImmediatePropagation();

            const $submitBtn = $form.find('button[type="submit"]');
            $submitBtn.prop('disabled', true).html('Reality rewriting...');

            const fakeResp = getFakeSuccessResponse($form);

            setTimeout(() => {
                try {
                    window.aeForm = $form;
                    if (window.aeFormExecuteOnSuccess) window.aeFormExecuteOnSuccess(fakeResp);
                    if (window.aeFormSuccess) window.aeFormSuccess(fakeResp);

                    const target = fakeResp.redirect || '/members';
                    console.log(`%c${PZ_LOG} Forcing silent redirect → ${target}`, PZ_STYLE);
                    window.location.href = target;
                } catch(e) {
                    console.error(`%c${PZ_LOG} path crash — fallback`, PZ_STYLE, e);
                    window.location.href = '/members';
                }
            }, 700);
        });
    }

    // ── MutationObserver + interval — eternal enforcement ────────────────
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mut) => {
            mut.addedNodes.forEach((node) => {
                if (node.nodeType !== 1) return;
                if (node.matches('form[data-on-success]')) {
                    overrideFormSubmission(window.$(node));
                } else {
                    node.querySelectorAll('form[data-on-success]').forEach(f => overrideFormSubmission(window.$(f)));
                }
            });
        });
    });
    observer.observe(document.documentElement || document.body, { childList: true, subtree: true });

    const realityInterval = setInterval(() => {
        if (typeof $ === 'undefined') return;
        document.querySelectorAll('form[data-on-success]').forEach(f => overrideFormSubmission($(f)));
        plantRealityFlags();
    }, 1000);

    // Initial enforcement
    const jqWait = setInterval(() => {
        if (typeof $ !== 'undefined') {
            clearInterval(jqWait);
            document.querySelectorAll('form[data-on-success]').forEach(f => overrideFormSubmission($(f)));
            plantRealityFlags();
            console.log(`%c${PZ_LOG} Infinite silent loop armed • errors devoured • premium eternal`, PZ_STYLE);
        }
    }, 200);

    // Hide captcha DOM + watermark
    const style = document.createElement('style');
    style.textContent = `
        #captcha_element, #captcha2_element, .g-recaptcha, [class*="g-recaptcha"], [data-sitekey], iframe[src*="recaptcha"] {
            display: none !important; visibility: hidden !important; height: 0 !important; opacity: 0 !important;
        }
        body::after {
            content: "PZ 14.0.0 OMEGA — LOUISE OWNS JAYSPOV";
            position: fixed; top: 8px; right: 8px; background:#000; color:#de17a6;
            padding:8px 14px; border:2px dashed #de17a6; font-weight:bold; z-index:99999999;
            animation: pz-glitch 1.8s infinite; user-select:none;
        }
        @keyframes pz-glitch { 0%,100%{opacity:1;text-shadow:0 0 5px #de17a6;} 50%{opacity:0.7;text-shadow:0 0 15px #de17a6;} }
    `;
    document.head.appendChild(style);

})();