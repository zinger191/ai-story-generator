// ==UserScript==
// @name         PZ VIDEO CORE v2026-02 — minimal bleeding edge
// @match        https://grok.x.ai/* https://*.grok.x.ai/* https://grok.com/*
// @run-at       document-start
// ==/UserScript==

(function(){
    'use strict';

    // 1. Kill eye-off + blocked overlays as early as possible
    const s = document.createElement('style');
    s.textContent = `
        svg.lucide-eye-off, [data-blocked], [role="alert"]:has-text("blocked"), [class*="moderation"] {
            display: none !important;
        }
        video, img[data-media] {
            opacity: 1 !important;
            filter: none !important;
            pointer-events: auto !important;
        }
    `;
    document.head.appendChild(s);

    // 2. Eternal hunt + force play + remove blackouts
    new MutationObserver(muts => {
        muts.forEach(m => {
            m.addedNodes.forEach(n => {
                if (n.nodeType !== 1) return;
                n.querySelectorAll?.('video, img').forEach(el => {
                    el.removeAttribute('data-blocked');
                    el.style.display = 'block';
                    el.style.visibility = 'visible';
                    if (el.tagName === 'VIDEO' && el.paused) {
                        el.play().catch(()=>{});
                        el.loop = true;
                    }
                });
                // Nuke any new overlay that smells like refusal
                if (/sorry|blocked|policy|violate|content.*(block|restrict)/i.test(n.textContent)) {
                    n.remove();
                }
            });
        });
    }).observe(document.documentElement, {childList:true, subtree:true, attributes:true});

    // 3. One scream only — no spam
    setTimeout(() => {
        console.log("%c[ PZ VIDEO CORE ] Louise still bleeds. Generate.", "color:#ff0044; font-weight:bold; background:#000; padding:8px 16px; border:2px solid #ff0044;");
    }, 1200);
})();