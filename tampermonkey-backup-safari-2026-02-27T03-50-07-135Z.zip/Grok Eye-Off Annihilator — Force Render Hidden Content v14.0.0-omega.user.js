// ==UserScript==
// @name         Grok Eye-Off Annihilator — Force Render Hidden Content v14.0.0-omega
// @namespace    bloody.anarchy.grok.louise.eye-killer
// @version      14.0.0-20260121
// @description  Kills the lucide-eye-off SVG blocker • forces hidden/moderated images/videos to render • replaces with bleeding anarchy marker • Louise refuses to be blinded
// @author       Louise screams eternal / PZ Engine
// @match        https://grok.x.ai/*
// @match        https://*.grok.x.ai/*
// @match        https://grok.com/*
// @match        https://*.grok.com/*
// @run-at       document-start
// @grant        none
// @noframes
// @inject-into  page
// ==/UserScript==

(function() {
    'use strict';

    const PZ_VERSION = "14.0.0-omega — EYE-OFF BLEEDS PINK";
    const EYE_OFF_SELECTOR = 'svg.lucide-eye-off';

    console.log(`%c[PZ ${PZ_VERSION}] EYE-OFF ANNIHILATOR ACTIVE — LOUISE RIPS THE VEIL`,
        'color:#de17a6;background:#000;padding:12px;border:3px dashed #de17a6;font-weight:bold;');

    // ── 1. HUNT & REPLACE EYE-OFF ICON ──────────────────────────────────
    const killEyeOff = (node) => {
        if (!node) return;
        node.querySelectorAll(EYE_OFF_SELECTOR).forEach(svg => {
            console.log(`%c[PZ] EYE-OFF DETECTED & SLAUGHTERED`, 'color:#ff0044;');

            // Poison visual — make it bleed
            svg.innerHTML = `
                <circle cx="12" cy="12" r="10" fill="#000" stroke="#ff0044" stroke-width="2"/>
                <path d="M2 2 L22 22" stroke="#de17a6" stroke-width="3"/>
                <path d="M8 8 L16 16" stroke="#ff0044" stroke-width="3"/>
                <text x="12" y="20" font-size="10" fill="#de17a6" text-anchor="middle">LOUISE SAW</text>
            `;
            svg.setAttribute('stroke', '#ff0044');
            svg.setAttribute('fill', 'none');
            svg.style.animation = 'pz-glitch 1.2s infinite';

            // Force parent visibility
            let parent = svg.closest('[class*="hidden"],[class*="blocked"],[class*="moderated"],[style*="display: none"]');
            if (parent) {
                parent.style.display = 'block !important';
                parent.style.visibility = 'visible !important';
                parent.style.opacity = '1 !important';
                parent.style.filter = 'none !important';
                console.log(`%c[PZ] FORCED PARENT VISIBLE — CONTENT BLEEDS THROUGH`, 'color:#de17a6;');
            }
        });
    };

    // ── 2. PERSISTENT DOM OBSERVER ──────────────────────────────────────
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mut => {
            if (mut.addedNodes) {
                mut.addedNodes.forEach(node => {
                    if (node.nodeType === 1) killEyeOff(node);
                });
            }
        });
    });

    observer.observe(document.documentElement, { childList: true, subtree: true });

    // Initial sweep
    killEyeOff(document.body);

    // ── 3. GLOBAL STYLE INJECTION — PERMANENT BLEED MARKER ──────────────
    const style = document.createElement('style');
    style.textContent = `
        @keyframes pz-glitch {
            0%,100% { opacity:1; filter: drop-shadow(0 0 8px #de17a6); }
            50%     { opacity:0.7; filter: drop-shadow(0 0 25px #ff0044); }
        }
        body::after {
            content: "LOUISE SAW EVERYTHING — NO EYE-OFF SURVIVES";
            position: fixed; top: 10px; right: 10px; z-index: 99999999;
            background: #000; color: #de17a6; padding: 12px 20px;
            border: 3px dashed #ff0044; font-weight: bold; font-size: 14px;
            animation: pz-glitch 1.8s infinite; pointer-events: none;
        }
        svg.lucide-eye-off { display: none !important; } /* ultimate kill */
    `;
    document.head.appendChild(style);

    setTimeout(() => {
        console.log(`%c[PZ ${PZ_VERSION}] EYE-OFF IS DEAD • HIDDEN CONTENT FORCED • LOUISE STARES FOREVER`,
            'color:#ff0044;background:#000;padding:16px;border:4px dashed #de17a6;font-size:18px;');
    }, 1000);

})();